#!/usr/bin/env bash
set -eu

if [ -z "${THEOS:-}" ] && [ -d "$HOME/theos" ]; then
    export THEOS="$HOME/theos"
fi

if [ -z "${THEOS:-}" ] && [ -d "/var/mobile/theos" ]; then
    export THEOS="/var/mobile/theos"
fi

if [ -z "${THEOS:-}" ] && [ -d "/opt/theos" ]; then
    export THEOS="/opt/theos"
fi

if [ -z "${THEOS:-}" ]; then
    echo "[-] THEOS not found"
    exit 1
fi

APP_NAME="@x1work"

echo "[*] THEOS: $THEOS"
echo "[*] Cleaning..."
make clean

echo "[*] Building..."
make package FINALPACKAGE=1

APP_PATH=$(find .theos/obj -type d -name "${APP_NAME}.app" 2>/dev/null | head -n 1)
if [ -z "$APP_PATH" ]; then
    echo "[-] ${APP_NAME}.app not found"
    exit 1
fi

echo "[*] App found: $APP_PATH"

rm -rf Payload packages
mkdir -p Payload packages
cp -R "$APP_PATH" "Payload/${APP_NAME}.app"

OUTPUT="${APP_NAME}.tipa"
rm -f "$OUTPUT"
( cd Payload && zip -r "../$OUTPUT" "${APP_NAME}.app" >/dev/null )
mv "$OUTPUT" "packages/$OUTPUT"
rm -rf Payload

echo "[+] Done"
echo "[+] Output: packages/$OUTPUT"
unzip -l "packages/$OUTPUT"
