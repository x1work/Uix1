//
//  HUDHelper.mm
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import <cstdint>
#import <spawn.h>
#import <notify.h>
#import <errno.h>
#import "rootless.h"
#import <mach-o/dyld.h>

#import "HUDHelper.h"

extern "C" char **environ;

#define POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE 1
extern "C" int posix_spawnattr_set_persona_np(const posix_spawnattr_t* __restrict, uid_t, uint32_t);
extern "C" int posix_spawnattr_set_persona_uid_np(const posix_spawnattr_t* __restrict, uid_t);
extern "C" int posix_spawnattr_set_persona_gid_np(const posix_spawnattr_t* __restrict, uid_t);

BOOL IsHUDEnabled(void)
{
    NSString *pidString = [NSString stringWithContentsOfFile:ROOT_PATH_NS(PID_PATH)
                                                    encoding:NSUTF8StringEncoding
                                                       error:nil];

    if (pidString)
    {
        pid_t pid = (pid_t)[pidString intValue];
        // kill(pid, 0) is a probe: 0 = signallable, -1 = something's wrong.
        // The HUD is spawned via posix_spawnattr_set_persona_np with uid=0
        // (root persona), so a mobile-uid caller gets EPERM even though the
        // process is alive and well. ESRCH is the only errno that actually
        // means "no such process". Anything else -- EPERM here, mostly --
        // means the pid exists, we just can't signal it.
        if (kill(pid, 0) == 0) return YES;
        return errno != ESRCH;
    }
    else return false;
}

void SetHUDEnabled(BOOL isEnabled)
{
    notify_post(NOTIFY_DESTROY_HUD);

    posix_spawnattr_t attr;
    posix_spawnattr_init(&attr);

    posix_spawnattr_set_persona_np(&attr, 99, POSIX_SPAWN_PERSONA_FLAGS_OVERRIDE);
    posix_spawnattr_set_persona_uid_np(&attr, 0);
    posix_spawnattr_set_persona_gid_np(&attr, 0);

    static char *executablePath = NULL;
    uint32_t executablePathSize = 0;
    _NSGetExecutablePath(NULL, &executablePathSize);
    executablePath = (char *)calloc(1, executablePathSize);
    _NSGetExecutablePath(executablePath, &executablePathSize);

    if (isEnabled)
    {
        posix_spawnattr_setpgroup(&attr, 0);
        posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);

        pid_t task_pid;
        const char *args[] = { executablePath, "-hud", NULL };
        posix_spawn(&task_pid, executablePath, NULL, &attr, (char **)args, environ);
        posix_spawnattr_destroy(&attr);
    }
    else
    {
        NSString *pidString = [NSString stringWithContentsOfFile:ROOT_PATH_NS(PID_PATH)
                                                        encoding:NSUTF8StringEncoding
                                                           error:nil];

        if (pidString)
        {
            pid_t pid = (pid_t)[pidString intValue];
            kill(pid, SIGKILL);
            unlink([ROOT_PATH_NS(PID_PATH) UTF8String]);
        }
    }
}
