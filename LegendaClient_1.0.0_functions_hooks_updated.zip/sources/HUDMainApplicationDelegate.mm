//
//  HUDMainApplicationDelegate.mm
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//  Updated to force landscape window and embed only ESP view into container (2025).
//
//
//  HUDMainApplicationDelegate.mm
//  @x1work
//

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

#import "HUDMainApplicationDelegate.h"
#import "HUDMainWindow.h"

#import "SBSAccessibilityWindowHostingController.h"
#import "UIWindow+Private.h"

#import "../esp/drawing_view/esp.h"
#import "UIView+SecureView.h"

@interface HUDLandscapeContainerViewController : UIViewController
@property (nonatomic, strong) UIView *contentView;
@end

@implementation HUDLandscapeContainerViewController

- (instancetype)init {
    self = [super init];
    if (self) {
        // Создаем контейнер СРАЗУ в init, чтобы он не был nil при настройке делегата
        CGRect screenBounds = [UIScreen mainScreen].bounds;
        CGRect landscapeBounds = CGRectMake(0, 0, MAX(screenBounds.size.width, screenBounds.size.height), MIN(screenBounds.size.width, screenBounds.size.height));
        
        self.contentView = [[UIView alloc] initWithFrame:landscapeBounds];
        self.contentView.backgroundColor = [UIColor clearColor];
        self.contentView.transform = CGAffineTransformMakeRotation(M_PI_2);
        self.contentView.center = CGPointMake(screenBounds.size.width / 2, screenBounds.size.height / 2);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    if (self.contentView) {
        [self.view addSubview:self.contentView];
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect screenBounds = [UIScreen mainScreen].bounds;
    self.contentView.center = CGPointMake(screenBounds.size.width / 2, screenBounds.size.height / 2);
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate {
    return NO;
}
@end

#pragma mark - HUDMainApplicationDelegate

@implementation HUDMainApplicationDelegate {
    SBSAccessibilityWindowHostingController *_windowHostingController;
}

- (instancetype)init
{
    if (self = [super init])
    {
        //log_debug(OS_LOG_DEFAULT, "- [HUDMainApplicationDelegate init]");
    }
    return self;
}

- (UIInterfaceOrientation)currentInterfaceOrientation {
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]) {
                UIWindowScene *ws = (UIWindowScene *)scene;
                if (ws.activationState == UISceneActivationStateForegroundActive ||
                    ws.activationState == UISceneActivationStateForegroundInactive) {
                    return ws.interfaceOrientation;
                }
            }
        }
    }

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    UIInterfaceOrientation sb = [UIApplication sharedApplication].statusBarOrientation;
#pragma clang diagnostic pop
    if (sb != UIInterfaceOrientationUnknown) {
        return sb;
    }

    UIDeviceOrientation dev = [UIDevice currentDevice].orientation;
    if (UIDeviceOrientationIsLandscape(dev)) {
        return (dev == UIDeviceOrientationLandscapeLeft) ? UIInterfaceOrientationLandscapeRight : UIInterfaceOrientationLandscapeLeft;
    }
    return UIInterfaceOrientationLandscapeRight;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary <UIApplicationLaunchOptionsKey, id> *)launchOptions
{
    //log_debug(OS_LOG_DEFAULT, "- [HUDMainApplicationDelegate application:%{public}@ didFinishLaunchingWithOptions:%{public}@]", application, launchOptions);

    HUDLandscapeContainerViewController *container = [[HUDLandscapeContainerViewController alloc] init];

    ESP_View *espView = [[ESP_View alloc] initWithFrame:container.contentView.bounds];
    espView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [container.contentView addSubview:espView];
    espView.userInteractionEnabled = YES;
    [espView hideViewFromCapture:NO];



    self.window = [[HUDMainWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [self.window setRootViewController:container];
    NSLog(@"andrdevv [self.window] initWithFrame: %@", NSStringFromCGRect(self.window.frame));

    [self.window setWindowLevel:10000010.0];
    [self.window setHidden:NO];
    [self.window makeKeyAndVisible];

    // Startup credit: a short, centered "@@x1work" animation.
    // It appears on launch, stays visible briefly, then fades away after ~1.5s.
    UILabel *startupCredit = [[UILabel alloc] initWithFrame:self.window.bounds];
    startupCredit.text = @"@@x1work";
    startupCredit.textColor = [UIColor whiteColor];
    startupCredit.font = [UIFont systemFontOfSize:28.0 weight:UIFontWeightSemibold];
    startupCredit.textAlignment = NSTextAlignmentCenter;
    startupCredit.backgroundColor = [UIColor clearColor];
    startupCredit.userInteractionEnabled = NO;
    startupCredit.alpha = 0.0;
    startupCredit.transform = CGAffineTransformMakeScale(0.94, 0.94);
    startupCredit.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.window addSubview:startupCredit];

    [UIView animateWithDuration:0.25
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         startupCredit.alpha = 1.0;
                         startupCredit.transform = CGAffineTransformIdentity;
                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.45
                                               delay:0.80
                                             options:UIViewAnimationOptionCurveEaseIn
                                          animations:^{
                                              startupCredit.alpha = 0.0;
                                              startupCredit.transform = CGAffineTransformMakeScale(1.03, 1.03);
                                          }
                                          completion:^(BOOL finished2) {
                                              [startupCredit removeFromSuperview];
                                          }];
                     }];

    [container.view setNeedsLayout];
    [container.view layoutIfNeeded];

    espView.frame = container.contentView.bounds;

    // Show the menu reliably on every fresh HUD launch (e.g. after Run).
    // Delay until ESP_View has registered its notification observer and the
    // overlay window is attached; this does not alter the three-finger toggle.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter]
            postNotificationName:@"LegendaClientMenuToggle" object:nil];
    });

    _windowHostingController = [[objc_getClass("SBSAccessibilityWindowHostingController") alloc] init];
    unsigned int _contextId = [self.window _contextId];
    double windowLevel = [self.window windowLevel];

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:"v@:Id"];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    [invocation setTarget:_windowHostingController];
    [invocation setSelector:NSSelectorFromString(@"registerWindowWithContextID:atLevel:")];
    [invocation setArgument:&_contextId atIndex:2];
    [invocation setArgument:&windowLevel atIndex:3];
    [invocation invoke];
#pragma clang diagnostic pop

    return YES;
}

@end
