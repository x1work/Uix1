//
//  TSEventFetcher.mm
//  @x1work
//
//

#import <CoreFoundation/CoreFoundation.h>
#import "TSEventFetcher.h"
#import "UIEvent+Private.h"
#import "UITouch-KIFAdditions.h"
#import "UIApplication+Private.h"
#include <atomic>

#ifdef __LP64__
typedef double TSHIDFloat;
#else
typedef float TSHIDFloat;
#endif

extern "C" {
uint32_t IOHIDEventGetType(IOHIDEventRef event);
CFArrayRef IOHIDEventGetChildren(IOHIDEventRef event);
CFIndex IOHIDEventGetIntegerValue(IOHIDEventRef event, uint32_t field);
TSHIDFloat IOHIDEventGetFloatValue(IOHIDEventRef event, uint32_t field);
}

static const uint32_t kTSEventTypeDigitizer = 11;
#define TS_DIGITIZER_FIELD(n) ((kTSEventTypeDigitizer << 16) + (n))
static const uint32_t kTSFieldX         = TS_DIGITIZER_FIELD(0);
static const uint32_t kTSFieldY         = TS_DIGITIZER_FIELD(1);
static const uint32_t kTSFieldIndex     = TS_DIGITIZER_FIELD(5);
static const uint32_t kTSFieldIdentity  = TS_DIGITIZER_FIELD(6);
static const uint32_t kTSFieldEventMask = TS_DIGITIZER_FIELD(7);
static const uint32_t kTSFieldRange     = TS_DIGITIZER_FIELD(8);
static const uint32_t kTSFieldTouch     = TS_DIGITIZER_FIELD(9);

static const uint32_t kTSMaskRange     = 1 << 0;
static const uint32_t kTSMaskTouch     = 1 << 1;
static const uint32_t kTSMaskPosition  = 1 << 2;
static const uint32_t kTSMaskAttribute = 1 << 6;
static const uint32_t kTSMaskCancel    = 1 << 7;

static NSMutableArray *_touchAry = nil;
static NSMutableArray *_livingTouchAry = nil;

static std::atomic_int  gSyntheticDepth{0};
static std::atomic_int  gEnqueuedDowns{0};
static std::atomic_int  gOrganicDeliveries{0};
static std::atomic_bool gPath1Dead{false};
static CFAbsoluteTime   gFirstDownTime = 0;

#pragma mark - HID decoding

static BOOL TSDecodeFinger(IOHIDEventRef finger, CGSize screen, TSHIDTouch *out)
{
    uint32_t mask = (uint32_t)IOHIDEventGetIntegerValue(finger, kTSFieldEventMask);
    BOOL touching = IOHIDEventGetIntegerValue(finger, kTSFieldTouch) != 0;
    BOOL inRange  = IOHIDEventGetIntegerValue(finger, kTSFieldRange) != 0;

    UITouchPhase phase;
    if (mask & kTSMaskCancel) {
        phase = UITouchPhaseCancelled;
    } else if (mask & kTSMaskTouch) {
        phase = touching ? UITouchPhaseBegan : UITouchPhaseEnded;
    } else if (touching && (mask & (kTSMaskPosition | kTSMaskAttribute))) {
        phase = UITouchPhaseMoved;
    } else if (!touching && !inRange && (mask & kTSMaskRange)) {
        phase = UITouchPhaseEnded;
    } else {
        return NO;
    }

    TSHIDFloat x = IOHIDEventGetFloatValue(finger, kTSFieldX);
    TSHIDFloat y = IOHIDEventGetFloatValue(finger, kTSFieldY);
    // Digitizer coordinates arrive normalized (0..1) on most devices.
    CGPoint location = (x <= 1.5 && y <= 1.5)
                         ? CGPointMake(x * screen.width, y * screen.height)
                         : CGPointMake(x, y);

    CFIndex index    = IOHIDEventGetIntegerValue(finger, kTSFieldIndex);
    CFIndex identity = IOHIDEventGetIntegerValue(finger, kTSFieldIdentity);
    NSInteger pointerId = index > 0 ? (NSInteger)index
                                    : (identity > 1 ? (NSInteger)identity - 1 : 1);

    out->location  = location;
    out->phase     = phase;
    out->pointerId = MIN(MAX(pointerId, 1), 98);
    return YES;
}

NSUInteger TSDecodeHIDTouches(IOHIDEventRef event, TSHIDTouch *out, NSUInteger cap)
{
    if (!event || !out || cap == 0) return 0;
    if (IOHIDEventGetType(event) != kTSEventTypeDigitizer) return 0;

    static CGSize screen = {0, 0};
    if (screen.width < 1.0 || screen.height < 1.0)
        screen = [[UIScreen mainScreen] bounds].size;
    if (screen.width < 1.0 || screen.height < 1.0) return 0;

    NSUInteger count = 0;
    CFArrayRef children = IOHIDEventGetChildren(event);
    CFIndex childCount = children ? CFArrayGetCount(children) : 0;

    for (CFIndex i = 0; i < childCount && count < cap; i++) {
        IOHIDEventRef child = (IOHIDEventRef)CFArrayGetValueAtIndex(children, i);
        if (!child || IOHIDEventGetType(child) != kTSEventTypeDigitizer) continue;
        if (TSDecodeFinger(child, screen, &out[count])) count++;
    }

    if (count == 0 && childCount == 0 && TSDecodeFinger(event, screen, &out[0]))
        count = 1;

    return count;
}

#pragma mark - Path 1 diagnostics

BOOL TSSyntheticDeliveryActive(void) { return gSyntheticDepth.load() > 0; }
void TSTouchNoteOrganicDelivery(void) { gOrganicDeliveries.fetch_add(1); }
BOOL TSTouchPath1IsDead(void) { return gPath1Dead.load(); }

void TSTouchNoteEnqueuedDown(void)
{
    int downs = gEnqueuedDowns.fetch_add(1) + 1;
    if (downs == 1) {
        gFirstDownTime = CFAbsoluteTimeGetCurrent();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (gOrganicDeliveries.load() == 0) gPath1Dead.store(true);
        });
    } else if (gOrganicDeliveries.load() == 0 &&
               CFAbsoluteTimeGetCurrent() - gFirstDownTime > 0.6) {
        gPath1Dead.store(true);
    }
}

#pragma mark - Synthetic delivery

// Deliver synchronously and clean up right after sendEvent:. The old
// @x1work fetcher deferred delivery to a run-loop source and only removed
// ended touches on the *next* incoming event, and it dropped the first Moved
// after Began -- enough for taps, broken for sliders, switches and scrolling.
static BOOL TSDeliverLivingTouches(void)
{
    if (_livingTouchAry.count == 0) return NO;

    UIApplication *app = [UIApplication sharedApplication];
    UIEvent *event = [app _touchesEvent];
    [event _clearTouches];

    NSArray *snapshot = [_livingTouchAry copy];
    for (UITouch *aTouch in snapshot)
        [event _addTouch:aTouch forDelayedDelivery:NO];

    gSyntheticDepth.fetch_add(1);
    [app sendEvent:event];
    gSyntheticDepth.fetch_sub(1);

    BOOL removed = NO;
    for (UITouch *aTouch in snapshot) {
        switch (aTouch.phase) {
        case UITouchPhaseEnded:
        case UITouchPhaseCancelled:
            [_livingTouchAry removeObjectIdenticalTo:aTouch];
            removed = YES;
            break;
        case UITouchPhaseBegan:
        case UITouchPhaseMoved:
            [aTouch setPhaseAndUpdateTimestamp:UITouchPhaseStationary];
            break;
        default:
            break;
        }
    }
    return removed;
}

static void TSEnsureTouchPools(void)
{
    if (_touchAry.count > 0) return;

    _livingTouchAry = [[NSMutableArray alloc] init];
    _touchAry = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < 100; i++) {
        UITouch *touch = [[UITouch alloc] initTouch];
        [touch setPhaseAndUpdateTimestamp:UITouchPhaseEnded];
        [_touchAry addObject:touch];
    }
}

@implementation TSEventFetcher

+ (void)load
{
    TSEnsureTouchPools();
}

+ (NSInteger)receiveAXEventID:(NSInteger)eventId
           atGlobalCoordinate:(CGPoint)coordinate
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view
{
    TSEnsureTouchPools();

    eventId -= 1;
    if (eventId < 0 || eventId >= (NSInteger)_touchAry.count) return NO;

    UITouch *touch = _touchAry[eventId];
    BOOL living = [_livingTouchAry containsObject:touch];

    if (!living) {
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) return NO;
        if (view == nil) return NO;
        touch = [[UITouch alloc] initAtPoint:coordinate inWindow:window onView:view];
        [_livingTouchAry addObject:touch];
        [_touchAry setObject:touch atIndexedSubscript:eventId];
    } else {
        [touch setLocationInWindow:coordinate];
    }

    [touch setPhaseAndUpdateTimestamp:phase];
    return TSDeliverLivingTouches();
}

@end
