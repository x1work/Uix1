#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <notify.h>

#import "HUDHelper.h"
#import "RootViewController.h"

#define kMenuPosPath   @"/var/mobile/Library/Preferences/@x1work_menu_position.txt"
#define kMenuPosNotify "com.@x1work.menu_position_changed"

static UIColor *ZWText(void)  { return [UIColor colorWithWhite:0.98 alpha:1.0]; }
static UIColor *ZWMuted(void) { return [UIColor colorWithWhite:0.72 alpha:1.0]; }
static UIColor *ZWBlue(void)  { return [UIColor colorWithRed:0.22 green:0.58 blue:1.0 alpha:1.0]; }

@interface RootViewController ()
@property(nonatomic, strong) AVPlayer *backgroundPlayer;
@property(nonatomic, strong) AVPlayerLayer *backgroundLayer;
@property(nonatomic, strong) UIView *shadeView;
@property(nonatomic, strong) UIImageView *logoView;
@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) UILabel *subtitleLabel;
@property(nonatomic, strong) UIView *optionsPanel;
@property(nonatomic, strong) UIButton *settingsButton;
@property(nonatomic, strong) UIButton *runButton;
@end

@implementation RootViewController

- (BOOL)isHUDEnabled { return IsHUDEnabled(); }
- (void)setHUDEnabled:(BOOL)enabled { SetHUDEnabled(enabled); }

- (void)loadView {
    self.view = [[UIView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.view.backgroundColor = UIColor.blackColor;
    [self buildBackground];
    [self buildLauncher];
}

#pragma mark - Background

- (void)buildBackground {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"back" ofType:@"mp4"];
    if (path.length) {
        self.backgroundPlayer = [AVPlayer playerWithURL:[NSURL fileURLWithPath:path]];
        self.backgroundPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        self.backgroundLayer = [AVPlayerLayer playerLayerWithPlayer:self.backgroundPlayer];
        self.backgroundLayer.frame = self.view.bounds;
        self.backgroundLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        [self.view.layer addSublayer:self.backgroundLayer];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(loopBackground)
                                                     name:AVPlayerItemDidPlayToEndTimeNotification
                                                   object:self.backgroundPlayer.currentItem];
        [self.backgroundPlayer play];
    }

    self.shadeView = [[UIView alloc] initWithFrame:self.view.bounds];
    self.shadeView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.shadeView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.08];
    [self.view addSubview:self.shadeView];
}

- (void)loopBackground {
    [self.backgroundPlayer seekToTime:kCMTimeZero completionHandler:^(BOOL finished) {
        [self.backgroundPlayer play];
    }];
}

#pragma mark - @@x1work launcher

- (UIButton *)launcherRowWithTitle:(NSString *)title icon:(NSString *)symbol action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:ZWText() forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightRegular];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    button.contentEdgeInsets = UIEdgeInsetsMake(0, 58, 0, 46);
    button.backgroundColor = UIColor.clearColor;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];

    if (@available(iOS 13.0, *)) {
        UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbol]];
        icon.tintColor = ZWText();
        icon.contentMode = UIViewContentModeScaleAspectFit;
        icon.frame = CGRectMake(18, 18, 27, 27);
        icon.userInteractionEnabled = NO;
        [button addSubview:icon];

        UIImageView *chevron = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"chevron.right"]];
        chevron.tintColor = [UIColor colorWithWhite:1 alpha:0.22];
        chevron.contentMode = UIViewContentModeScaleAspectFit;
        chevron.frame = CGRectMake(0, 0, 20, 28);
        chevron.tag = 91337;
        chevron.userInteractionEnabled = NO;
        [button addSubview:chevron];
    }
    return button;
}

- (void)buildLauncher {
    self.logoView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo.png"]];
    self.logoView.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:self.logoView];

    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = @"@x1work";
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = ZWText();
    self.titleLabel.font = [UIFont systemFontOfSize:44 weight:UIFontWeightBold];
    [self.view addSubview:self.titleLabel];

    self.subtitleLabel = [[UILabel alloc] init];
    self.subtitleLabel.text = @"t.me/LegendaClient\nTrollStore";
    self.subtitleLabel.numberOfLines = 2;
    self.subtitleLabel.textAlignment = NSTextAlignmentCenter;
    self.subtitleLabel.textColor = ZWMuted();
    self.subtitleLabel.font = [UIFont systemFontOfSize:21 weight:UIFontWeightSemibold];
    self.subtitleLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *subtitleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openTelegramChannel)];
    [self.subtitleLabel addGestureRecognizer:subtitleTap];
    [self.view addSubview:self.subtitleLabel];

    self.optionsPanel = [[UIView alloc] init];
    self.optionsPanel.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.055];
    self.optionsPanel.layer.cornerRadius = 14.0;
    self.optionsPanel.clipsToBounds = YES;
    [self.view addSubview:self.optionsPanel];

    self.settingsButton = [self launcherRowWithTitle:@"Settings" icon:@"gearshape.2" action:@selector(openSettings)];
    [self.optionsPanel addSubview:self.settingsButton];

    self.runButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.runButton setTitleColor:ZWText() forState:UIControlStateNormal];
    self.runButton.titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightMedium];
    [self.runButton addTarget:self action:@selector(tapMainButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.runButton];

    [self updateMainState];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.backgroundLayer.frame = self.view.bounds;
    self.shadeView.frame = self.view.bounds;

    CGRect b = self.view.bounds;
    CGFloat W = CGRectGetWidth(b), H = CGRectGetHeight(b);
    CGFloat safeTop = self.view.safeAreaInsets.top;

    CGFloat logoSize = MIN(190.0, MAX(118.0, W * 0.34));
    CGFloat logoY = safeTop + MAX(35.0, H * 0.085);
    self.logoView.frame = CGRectMake((W - logoSize) * 0.5, logoY, logoSize, logoSize);

    CGFloat titleY = CGRectGetMaxY(self.logoView.frame) + 15.0;
    self.titleLabel.frame = CGRectMake(18, titleY, W - 36, 58);

    CGFloat subtitleY = CGRectGetMaxY(self.titleLabel.frame) + 2.0;
    self.subtitleLabel.frame = CGRectMake(18, subtitleY, W - 36, 58);

    CGFloat panelW = MIN(410.0, W - 100.0);
    if (panelW < 300.0) panelW = W - 42.0;
    CGFloat panelH = 74.0;
    CGFloat panelY = MIN(H - 300.0, CGRectGetMaxY(self.subtitleLabel.frame) + 42.0);
    if (panelY < CGRectGetMaxY(self.subtitleLabel.frame) + 16.0)
        panelY = CGRectGetMaxY(self.subtitleLabel.frame) + 16.0;
    self.optionsPanel.frame = CGRectMake((W - panelW) * 0.5, panelY, panelW, panelH);

    self.settingsButton.frame = CGRectMake(0, 0, panelW, panelH);

    for (UIButton *row in @[self.settingsButton]) {
        UIImageView *chev = (UIImageView *)[row viewWithTag:91337];
        chev.frame = CGRectMake(panelW - 42, (CGRectGetHeight(row.bounds)-28)/2.0, 20, 28);
    }

    CGFloat runY = MIN(H - self.view.safeAreaInsets.bottom - 90.0, CGRectGetMaxY(self.optionsPanel.frame) + 62.0);
    self.runButton.frame = CGRectMake((W - 180.0) * 0.5, runY, 180.0, 52.0);
}

#pragma mark - Actions

- (void)openSettings {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Settings"
                                                               message:@"Menu position"
                                                        preferredStyle:UIAlertControllerStyleAlert];
    NSArray<NSString *> *titles = @[@"Top Left", @"Top Right", @"Bottom Left", @"Bottom Right", @"Center"];
    for (NSInteger i = 0; i < titles.count; i++) {
        [a addAction:[UIAlertAction actionWithTitle:titles[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self writeMenuPosition:i];
        }]];
    }
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    a.view.tintColor = ZWBlue();
    [self presentViewController:a animated:YES completion:nil];
}

- (void)openTelegramChannel {
    NSURL *url = [NSURL URLWithString:@"https://t.me/LegendaClient"];
    if (!url) return;
    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

- (void)showRunWarning {
    NSString *message = @"Внимание! Нажимая на кнопку уведомления ниже, Вы осознаете последствия и соглашаетесь с тем, что именно Вы несете всю ответственность.";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Предупреждение"
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK, я согласен"
                                                 style:UIAlertActionStyleDefault
                                               handler:^(UIAlertAction *action) {
        [self setHUDEnabled:YES];
        [self updateMainState];
    }];
    [alert addAction:ok];
    alert.view.tintColor = ZWBlue();
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)tapMainButton:(UIButton *)sender {
    if ([self isHUDEnabled]) {
        [self setHUDEnabled:NO];
        [self updateMainState];
        return;
    }

    // Start the menu immediately, then open the LegendaClient Telegram channel.
    [self setHUDEnabled:YES];
    [self updateMainState];
    [self openTelegramChannel];
}

- (void)reloadMainButtonState { [self updateMainState]; }

- (void)updateMainState {
    BOOL active = [self isHUDEnabled];
    [self.runButton setTitle:(active ? @"Exit" : @"Run") forState:UIControlStateNormal];
}

- (NSInteger)readSavedMenuPosition {
    NSString *str = [NSString stringWithContentsOfFile:kMenuPosPath encoding:NSUTF8StringEncoding error:nil];
    if (str.length) return MAX(0, MIN(4, str.integerValue));
    return 0;
}

- (void)writeMenuPosition:(NSInteger)pos {
    NSString *str = [NSString stringWithFormat:@"%ld", (long)MAX(0, MIN(4, pos))];
    [str writeToFile:kMenuPosPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    notify_post(kMenuPosNotify);
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self updateMainState];
}

- (UIStatusBarStyle)preferredStatusBarStyle { return UIStatusBarStyleLightContent; }

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
