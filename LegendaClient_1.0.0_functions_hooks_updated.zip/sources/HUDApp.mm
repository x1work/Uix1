#import <notify.h>
#import "rootless.h"
#import <sys/types.h>
#import <signal.h>
#import <unistd.h>
#import <dlfcn.h>
#import <objc/runtime.h>

#import "HUDHelper.h"
#import "TSEventFetcher.h"
#import "BackboardServices.h"
#import "AXEventRepresentation.h"
#import "UIApplication+Private.h"

typedef void (*ZW_GSInitializeFn)(void);
typedef void (*ZW_BKSDisplayServicesStartFn)(void);
typedef void (*ZW_GSEventInitializeFn)(Boolean);
typedef void (*ZW_GSEventPushRunLoopModeFn)(CFStringRef);
typedef void *(*ZW_BKSHIDEventRegisterEventCallbackFn)(
    void (*callback)(void *, void *, IOHIDServiceRef, IOHIDEventRef)
);

static void *ZWLoadFramework(const char *path)
{
    return dlopen(path, RTLD_LAZY | RTLD_LOCAL);
}

static void *ZWLookup(void *handle, const char *symbol)
{
    return handle ? dlsym(handle, symbol) : NULL;
}

static void ZWRouteSyntheticTouch(CGPoint location, UITouchPhase phase, NSInteger pointerId)
{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = [UIApplication sharedApplication];
        UIWindow *window = app.delegate.window ?: app.windows.firstObject;
        if (!window) return;

        UIView *keyView = [window hitTest:location withEvent:nil];
        if (pointerId > 0 && (keyView || phase != UITouchPhaseBegan)) {
            [TSEventFetcher receiveAXEventID:MIN(MAX(pointerId, 1), 98)
                          atGlobalCoordinate:location
                              withTouchPhase:phase
                                    inWindow:window
                                      onView:keyView];
        }
    });
}

void _HUDEventCallback(void *target,
                       void *refcon,
                       IOHIDServiceRef service,
                       IOHIDEventRef event)
{
    static UIApplication *app = [UIApplication sharedApplication];

    TSHIDTouch touches[8];
    NSUInteger touchCount = TSDecodeHIDTouches(event, touches, 8);

    static BOOL canEnqueueHIDEvent =
        [app respondsToSelector:@selector(_enqueueHIDEvent:)];

    if (canEnqueueHIDEvent && !TSTouchPath1IsDead()) {
        [app _enqueueHIDEvent:event];
        for (NSUInteger i = 0; i < touchCount; i++) {
            if (touches[i].phase == UITouchPhaseBegan)
                TSTouchNoteEnqueuedDown();
        }
        if (!TSTouchPath1IsDead()) return;
    }

    for (NSUInteger i = 0; i < touchCount; i++) {
        ZWRouteSyntheticTouch(touches[i].location,
                              touches[i].phase,
                              touches[i].pointerId);
    }
}

int main(int argc, char *argv[])
{
    @autoreleasepool {
        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");

        if (strcmp(argv[1], "-hud") != 0)
            return EXIT_SUCCESS;

        pid_t pid = getpid();
        NSString *pidString = [NSString stringWithFormat:@"%d", pid];
        [pidString writeToFile:ROOT_PATH_NS(PID_PATH)
                    atomically:YES
                      encoding:NSUTF8StringEncoding
                         error:nil];

        [UIScreen initialize];
        CFRunLoopGetCurrent();

        void *gsHandle = ZWLoadFramework(
            "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        void *bksHandle = ZWLoadFramework(
            "/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices");

        ZW_GSInitializeFn gsInitialize =
            (ZW_GSInitializeFn)ZWLookup(gsHandle, "GSInitialize");
        ZW_BKSDisplayServicesStartFn bksDisplayServicesStart =
            (ZW_BKSDisplayServicesStartFn)ZWLookup(bksHandle, "BKSDisplayServicesStart");
        ZW_BKSHIDEventRegisterEventCallbackFn bksRegisterCallback =
            (ZW_BKSHIDEventRegisterEventCallbackFn)ZWLookup(
                bksHandle, "BKSHIDEventRegisterEventCallback");

        if (gsInitialize) gsInitialize();
        if (bksDisplayServicesStart) bksDisplayServicesStart();

        UIApplicationInitialize();
        UIApplicationInstantiateSingleton(objc_getClass("HUDMainApplication"));

        static id<UIApplicationDelegate> appDelegate =
            [[objc_getClass("HUDMainApplicationDelegate") alloc] init];
        [UIApplication.sharedApplication setDelegate:appDelegate];
        [UIApplication.sharedApplication _accessibilityInit];
        [NSRunLoop currentRunLoop];

        if (bksRegisterCallback)
            bksRegisterCallback(_HUDEventCallback);

        if (@available(iOS 15.0, *)) {
            ZW_GSEventInitializeFn gsEventInitialize =
                (ZW_GSEventInitializeFn)ZWLookup(gsHandle, "GSEventInitialize");
            ZW_GSEventPushRunLoopModeFn gsEventPushRunLoopMode =
                (ZW_GSEventPushRunLoopModeFn)ZWLookup(
                    gsHandle, "GSEventPushRunLoopMode");
            if (gsEventInitialize) gsEventInitialize(0);
            if (gsEventPushRunLoopMode)
                gsEventPushRunLoopMode(kCFRunLoopDefaultMode);
        }

        [UIApplication.sharedApplication __completeAndRunAsPlugin];

        static int springboardBootToken;
        notify_register_dispatch("SBSpringBoardDidLaunchNotification",
                                 &springboardBootToken,
                                 dispatch_get_main_queue(),
                                 ^(int token) {
            notify_cancel(token);
            notify_post(NOTIFY_DESTROY_HUD);
            SetHUDEnabled(YES);
            kill(pid, SIGKILL);
        });

        CFRunLoopRun();

        if (gsHandle) dlclose(gsHandle);
        if (bksHandle) dlclose(bksHandle);
        return EXIT_SUCCESS;
    }
}
