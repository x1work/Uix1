//
//  HUDMainWindow.mm
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import "HUDMainWindow.h"

@implementation HUDMainWindow

+ (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_isSecure { return NO; }
- (BOOL)_shouldCreateContextAsSecure { return NO; }

// Only the menu is interactive. ESP_View covers the whole screen, so without
// this every tap on the game would be claimed by the overlay.
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    static Class menuClass = NSClassFromString(@"MenuView");
    for (UIView *v = hit; v != nil; v = v.superview) {
        if ([v isKindOfClass:menuClass]) return hit;
    }
    return nil;
}

@end
