//
//  RootViewController.h
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@property (nonatomic, strong) UIView *backgroundView;

- (BOOL)isHUDEnabled;
- (void)setHUDEnabled:(BOOL)enabled;

// Вызывается из MainApplicationDelegate при смене состояния HUD
- (void)reloadMainButtonState;

@end
