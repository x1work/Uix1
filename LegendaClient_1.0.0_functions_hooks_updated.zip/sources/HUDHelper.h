//
//  HUDHelper.h
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import <Foundation/Foundation.h>

BOOL IsHUDEnabled(void);
void SetHUDEnabled(BOOL isEnabled);