//
//  TSEventFetcher.h
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import <UIKit/UIKit.h>
#import "IOKit+SPI.h"

@interface TSEventFetcher : NSObject
+ (NSInteger)receiveAXEventID:(NSInteger)pointId
           atGlobalCoordinate:(CGPoint)point
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view;
@end

typedef struct {
    CGPoint location;
    UITouchPhase phase;
    NSInteger pointerId;
} TSHIDTouch;

#ifdef __cplusplus
extern "C" {
#endif

NSUInteger TSDecodeHIDTouches(IOHIDEventRef event, TSHIDTouch *out, NSUInteger cap);

// Path 1 = real HID events enqueued into UIKit. Declared dead when a touch-down
// was enqueued but UIKit never delivered any touch event within 0.6s; from then
// on touches are synthesized instead.
BOOL TSSyntheticDeliveryActive(void);
void TSTouchNoteEnqueuedDown(void);
void TSTouchNoteOrganicDelivery(void);
BOOL TSTouchPath1IsDead(void);

#ifdef __cplusplus
}
#endif
