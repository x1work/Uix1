//
//  MainApplication.h
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import <UIKit/UIKit.h>

@interface MainApplication : UIApplication
@end