//
//  MainApplication.mm
//  @x1work
//
//  Created by Lessica on 2024/1/24.
//

#import "MainApplication.h"

@implementation MainApplication
@end
