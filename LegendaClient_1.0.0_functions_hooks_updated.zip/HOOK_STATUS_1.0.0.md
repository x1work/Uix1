# 1.0.0 HOOK / ICALL STATUS

## UI hook
The project contains a UIKit/UIEventDispatcher hook used by the overlay/menu gesture.
It is independent of Standoff 2 game offsets and does not require a 1.0.0 game RVA update.

## Standoff 2 native paths
No dedicated Standoff 2 method hook implementation was present in the source.
The supplied 1.0.0 data confirms Unity native ICall registration stubs/RVAs for:
- Camera
- Transform
- Animator bones
- Renderer/Collider bounds
- Physics raycasts

Those are call targets, not replacement hook implementations. The current project is an external task-memory reader, so it cannot safely call those target-process functions as ordinary local function pointers.

## Gameplay hooks not claimed as updated
The supplied source explicitly does not validate:
- input/view-angle command path
- shot/hit submit
- recoil/spread/accuracy fields
- active weapon field chain beyond the type-based resolver

The previous ARM32 writes are therefore disabled from the 1.0.0 render path instead of being mislabeled as updated hooks.

## Result
The 1.0.0 source now uses the validated TypeInfo/FieldInfo player graph for player enumeration, team and HP resolution, and the candidate active-weapon/ammo chain. Unsupported gameplay hooks remain disabled until an ARM64 runtime trace provides their actual FieldInfo/method path.
