#!/usr/bin/env python3
"""Generate a machine-readable manifest for Standoff 2 1.0.0 ARM64.

The previous script parsed obsolete ARM32 dump.cs classes (including skins and
old PlayerManager chains).  The supplied 1.0.0 analysis explicitly says those
values must not be carried forward, so this script only emits the validated
RVA/type-info data used by the new runtime resolver.
"""
import json
from pathlib import Path

TYPEINFO = {
    "ClientWorld": "0xC1C2DB8",
    "Registry": "0xC1C0828",
    "Store": "0xC1C0CE8",
    "Player": "0xC1BEB30",
    "NetObject": "0xC1C27C0",
    "Transforms": "0xC1BFC80",
    "Stats": "0xC1C6810",
    "WeaponPart": "0xC1C2F80",
    "WeaponInstance": "0xC1C3D18",
    "Transport": "0xC1C0D50",
    "Actor": "0xC1C48D8",
}

ICALLS = {
    "Camera.WorldToScreenPoint_Injected": "0x5365268",
    "Camera.get_main_Injected": "0x53653C4",
    "Camera.get_worldToCameraMatrix_Injected": "0x5365204",
    "Camera.get_projectionMatrix_Injected": "0x5365228",
    "Transform.GetPositionAndRotation_Injected": "0x53764E0",
    "Animator.GetBoneTransformInternal_Injected": "0x539569C",
    "Renderer.get_bounds_Injected": "0x53689D0",
    "Collider.get_bounds_Injected": "0x538B650",
    "PhysicsScene.Internal_RaycastTest_Injected": "0x538BCF4",
    "PhysicsScene.Internal_Raycast_Injected": "0x538BD0C",
}

IL2CPP = {
    "il2cpp_class_from_name": "0x6327A3C",
    "il2cpp_class_get_field_from_name": "0x6327AD0",
    "il2cpp_class_get_fields": "0x6327AC8",
    "il2cpp_field_get_offset": "0x6327C44",
    "il2cpp_field_get_type": "0x6327C48",
    "il2cpp_method_get_name": "0x6327CEC",
    "il2cpp_runtime_invoke": "0x6327D44",
    "il2cpp_resolve_icall": "0x63279F4",
}

out = {
    "version": "1.0.0",
    "arch": "arm64",
    "typeinfo": TYPEINFO,
    "icalls": ICALLS,
    "il2cpp": IL2CPP,
    "skins": "removed: no longer part of the 1.0.0 runtime source",
}
Path("dump").mkdir(exist_ok=True)
Path("dump/so2_1_0_0_manifest.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print("wrote dump/so2_1_0_0_manifest.json")
