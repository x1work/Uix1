# LegendaClient — Standoff 2 1.0.0 migration

The uploaded `Standoff2_1.0.0_ARM64_valid_offsets.txt` is the source of truth for this migration.

## Updated
- ARM64 Unity ICall RVAs are centralized in `esp/unity_api/so2_v100_offsets.h`.
- ARM64 TypeInfo slots and TypeVar anchors are centralized there.
- `SO2V100::Runtime` resolves the ClientWorld -> Registry -> Store -> List graph by runtime type.
- Player enumeration filters by the 1.0.0 Player TypeInfo class.
- Local player uses OwnerId == ActorId when those named fields are present.
- Stats are resolved by field type; HP/max HP and armor candidates are read only after the Stats component is type-resolved.
- WeaponPart/WeaponContext/ActiveWeapon are resolved through FieldInfo/type descriptors before reading the supplied weapon/ammo candidates.
- The render loop no longer enumerates the old PlayerManager/Photon dictionary.
- Old gameplay writes are not executed against 1.0.0.

## Important 1.0.0 limitation
The supplied data explicitly marks HP/team/local-player semantics, recoil/spread, input/view-angle command, and shot/hit/network-submit paths as requiring runtime validation. The project therefore does not invent new offsets for them.

The supplied ICalls include WorldToScreen, Transform position/rotation, Animator bone, Bounds and Physics raycast entry points. This project is an external task-memory reader, so direct target-process ICall invocation requires a separate call bridge; the source does not pretend that a remote RVA is a callable local function pointer.

## Camera compatibility path
The existing external Transform/camera matrix memory walker remains as a compatibility fallback for rendering. It is isolated from the 1.0.0 player/object resolver and is not presented as a validated 1.0.0 ICall invocation.

## Hooks
See `HOOK_STATUS_1.0.0.md`. The project has a UI event hook for the menu, but no dedicated Standoff 2 method hook implementation. The supplied native ICall registration stubs are recorded, not incorrectly converted into hooks.
