@@x1work — Theos source

Build:
  1. Set THEOS to your Theos installation, or place Theos in ~/theos, /var/mobile/theos, or /opt/theos.
  2. From this folder run: ./build.sh
     or: make clean package FINALPACKAGE=1
  3. The packaged app is produced in packages/.

Branding / launcher:
  - App display name: @@x1work
  - Icy animated background + butterfly logo from the supplied UI reference
  - Main launcher: Settings, Run / Exit
  - Run displays the Russian responsibility warning before enabling the HUD
  - Subtitle opens https://t.me/LegendaClient
  - No runtime third-party web/audio URL is used by the edited source

In-game menu:
  - Compact dark translucent menu based on the supplied screenshot
  - Vertical tabs: Aimbot / Visuals / Player / Load / Skins / Misc
  - iOS-style switches, green sliders/selection controls
  - X collapses the menu to a 54x54 butterfly button; tap the butterfly to reopen it
  - Existing functions remain connected to their original state/callbacks

Player modules (esp/Player):
  - aim360.h/.mm          — 360-degree target scoring/context
  - alwh.h/.mm            — supplied Always Head / Hitbox module
  - freezep.h/.mm         — supplied local/enemy freeze module
  - molotov_flash.h/.mm   — supplied Anti Flash / Anti Molotov module

360 aim:
  - Aimbot FOV slider goes to 360
  - Values below 360 keep the original screen-space FOV selection
  - FOV=360 can acquire targets behind the camera using angular target selection
  - FOV circle is hidden at 360 because a screen-space circle cannot represent the full sphere

Build detail:
  APPLICATION_NAME / executable remains @x1work so the existing Theos target and launch code continue to work.
  CFBundleDisplayName and CFBundleName are @@x1work, which is the name shown to the user.

Bunny Hop: restored in the menu and uses the existing air-jump implementation/offsets from this project.
360 Aim: uses the existing aimController/aimingData/camera offsets from the project, with finite-value and frame-consistency safeguards.


STANDOFF 2 1.0.0 UPDATE
=======================
Use the supplied ARM64 validated offsets as the source of truth.
See:
  - MIGRATION_STATUS.md
  - HOOK_STATUS_1.0.0.md
  - esp/unity_api/so2_v100_offsets.h
  - esp/unity_api/so2_v100_runtime.mm

Legacy game-specific PlayerManager/Photon/PlayerController chains and their
old gameplay writes were removed/disabled from the active 1.0.0 path.
