#include "so2_v100_runtime.h"
#include "so2_v100_offsets.h"
#include <algorithm>
#include <cstring>
#include <cmath>
#include <mach/mach_vm.h>

using namespace SO2V100;

namespace {
static constexpr uintptr_t PTR_MIN = 0x1000000ULL;
static constexpr uintptr_t PTR_MAX = 0xFFFFFFFFFFFFULL;

static inline bool PtrOK(uintptr_t p) { return p >= PTR_MIN && p <= PTR_MAX; }

static uintptr_t TypeVarTarget(task_t task, uintptr_t base, uintptr_t rva) {
    if (!base) return 0;
    return Read<uintptr_t>(base + rva, task);
}

static uintptr_t TypeDescriptorClass(task_t task, uintptr_t type) {
    if (!PtrOK(type) || !task) return 0;
    // For reference/value class descriptors used by this build, the first
    // pointer is the Il2CppClass/definition pointer.
    uintptr_t klass = Read<uintptr_t>(type, task);
    return PtrOK(klass) ? klass : 0;
}
}

void Runtime::reset() {
    task_ = MACH_PORT_NULL;
    base_ = 0;
    world_ = 0;
    localPlayer_ = 0;
    ready_ = false;
}

bool Runtime::initialize(task_t task, uintptr_t unityBase) {
    reset();
    if (!task || !unityBase) return false;
    task_ = task;
    base_ = unityBase;

    // TypeInfo slots are only valid after metadata initialization.
    const uintptr_t playerClass = classAt(TypeInfo::PLAYER_AKE);
    const uintptr_t worldClass  = classAt(TypeInfo::CLIENTWORLD_NJH);
    if (!PtrOK(playerClass) || !PtrOK(worldClass)) return false;

    world_ = resolveWorld();
    ready_ = PtrOK(world_);
    return ready_;
}

uintptr_t Runtime::classAt(uintptr_t typeInfoRva) const {
    if (!task_ || !base_) return 0;
    return Read<uintptr_t>(base_ + typeInfoRva, task_);
}

std::string Runtime::readCString(uintptr_t p, size_t maxLen) const {
    if (!PtrOK(p) || !task_) return {};
    std::string s;
    s.reserve(maxLen);
    for (size_t i = 0; i < maxLen; ++i) {
        char c = Read<char>(p + i, task_);
        if (!c) break;
        s.push_back(c);
    }
    return s;
}

bool Runtime::isReadable(uintptr_t p) const {
    return PtrOK(p);
}

uintptr_t Runtime::findField(uintptr_t klass, uintptr_t expectedFieldClass) const {
    if (!PtrOK(klass) || !PtrOK(expectedFieldClass)) return 0;
    uintptr_t cur = klass;
    for (int depth = 0; depth < 32 && PtrOK(cur); ++depth) {
        const uint16_t count = Read<uint16_t>(cur + Layout::Il2CppClass_field_count, task_);
        const uintptr_t fields = Read<uintptr_t>(cur + Layout::Il2CppClass_fields, task_);
        if (PtrOK(fields) && count > 0 && count <= 4096) {
            for (uint16_t i = 0; i < count; ++i) {
                const uintptr_t field = Read<uintptr_t>(fields + sizeof(uintptr_t) * i, task_);
                if (!PtrOK(field)) continue;
                const uintptr_t type = Read<uintptr_t>(field + Layout::FieldInfo_type, task_);
                if (!PtrOK(type)) continue;
                const uintptr_t fieldClass = TypeDescriptorClass(task_, type);
                if (fieldClass == expectedFieldClass) return field;
            }
        }
        cur = Read<uintptr_t>(cur + Layout::Il2CppClass_parent, task_);
    }
    return 0;
}

uintptr_t Runtime::findFieldByNameRecursive(uintptr_t klass, const char *name) const {
    if (!PtrOK(klass) || !name) return 0;
    uintptr_t cur = klass;
    for (int depth = 0; depth < 32 && PtrOK(cur); ++depth) {
        const uint16_t count = Read<uint16_t>(cur + Layout::Il2CppClass_field_count, task_);
        const uintptr_t fields = Read<uintptr_t>(cur + Layout::Il2CppClass_fields, task_);
        if (PtrOK(fields) && count > 0 && count <= 4096) {
            for (uint16_t i = 0; i < count; ++i) {
                const uintptr_t field = Read<uintptr_t>(fields + sizeof(uintptr_t) * i, task_);
                if (!PtrOK(field)) continue;
                const uintptr_t namePtr = Read<uintptr_t>(field + Layout::FieldInfo_name, task_);
                if (readCString(namePtr) == name) return field;
            }
        }
        cur = Read<uintptr_t>(cur + Layout::Il2CppClass_parent, task_);
    }
    return 0;
}

uintptr_t Runtime::typeClassFromVar(uintptr_t typeVarRva) const {
    return TypeDescriptorClass(task_, TypeVarTarget(task_, base_, typeVarRva));
}

uintptr_t Runtime::findFieldByTypeVar(uintptr_t klass, uintptr_t typeVarRva) const {
    return findField(klass, typeClassFromVar(typeVarRva));
}

uintptr_t Runtime::findFieldByName(uintptr_t klass, const char *name) const {
    return findFieldByNameRecursive(klass, name);
}

uintptr_t Runtime::fieldValue(uintptr_t object, uintptr_t field) const {
    if (!PtrOK(object) || !PtrOK(field)) return 0;
    const uintptr_t off = Read<uintptr_t>(field + Layout::FieldInfo_offset, task_);
    if (off > 0x100000) return 0;
    return Read<uintptr_t>(object + off, task_);
}

uintptr_t Runtime::findObjectByClass(uintptr_t klass) const {
    if (!PtrOK(klass) || !task_) return 0;

    // One-time heap scan. This deliberately searches writable/readable regions
    // and checks exact object->klass equality, as required by the supplied 1.0.0
    // runtime-validation notes. It is not a guessed PlayerManager chain.
    mach_vm_address_t address = 0;
    while (true) {
        mach_vm_size_t size = 0;
        vm_region_submap_info_data_64_t info{};
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
        uint32_t depth = 0;
        kern_return_t kr = mach_vm_region_recurse(task_, &address, &size, &depth,
                                                  (vm_region_recurse_info_t)&info, &count);
        if (kr != KERN_SUCCESS) break;
        const mach_vm_address_t next = address + size;
        if ((info.protection & VM_PROT_READ) && (info.protection & VM_PROT_WRITE) && size >= 0x1000) {
            const mach_vm_size_t scanSize = std::min<mach_vm_size_t>(size, 64ULL * 1024ULL * 1024ULL);
            const size_t chunkSize = 0x4000;
            std::vector<uint8_t> buf(chunkSize);
            for (mach_vm_address_t off = 0; off < scanSize; off += chunkSize) {
                const mach_vm_size_t want = std::min<mach_vm_size_t>(chunkSize, scanSize - off);
                mach_vm_size_t got = 0;
                if (mach_vm_read_overwrite(task_, address + off, want,
                                            (mach_vm_address_t)buf.data(), &got) != KERN_SUCCESS || got < sizeof(uintptr_t))
                    continue;
                for (size_t i = 0; i + sizeof(uintptr_t) <= got; i += sizeof(uintptr_t)) {
                    uintptr_t candidate = 0;
                    memcpy(&candidate, buf.data() + i, sizeof(candidate));
                    if (candidate == klass) return address + off + i - Layout::Il2CppObject_klass;
                }
            }
        }
        address = next;
        if (address == 0 || address < next) break;
    }
    return 0;
}

uintptr_t Runtime::resolveWorld() {
    return findObjectByClass(classAt(TypeInfo::CLIENTWORLD_NJH));
}

uintptr_t Runtime::resolveAllObjectsList(uintptr_t storage) const {
    if (!PtrOK(storage)) return 0;
    const uintptr_t storageClass = Read<uintptr_t>(storage + Layout::Il2CppObject_klass, task_);
    const uint16_t count = Read<uint16_t>(storageClass + Layout::Il2CppClass_field_count, task_);
    const uintptr_t fields = Read<uintptr_t>(storageClass + Layout::Il2CppClass_fields, task_);
    if (!PtrOK(fields) || count == 0 || count > 4096) return 0;

    const uintptr_t netClass = classAt(TypeInfo::NETOBJECT_MFC);
    const uintptr_t playerClass = classAt(TypeInfo::PLAYER_AKE);
    for (uint16_t i = 0; i < count; ++i) {
        const uintptr_t field = Read<uintptr_t>(fields + sizeof(uintptr_t) * i, task_);
        if (!PtrOK(field)) continue;
        const uintptr_t off = Read<uintptr_t>(field + Layout::FieldInfo_offset, task_);
        if (off > 0x100000) continue;
        const uintptr_t list = Read<uintptr_t>(storage + off, task_);
        if (!PtrOK(list)) continue;
        const uintptr_t items = Read<uintptr_t>(list + Layout::List_items, task_);
        const int size = Read<int>(list + Layout::List_size, task_);
        if (!PtrOK(items) || size <= 0 || size > 4096) continue;
        for (int j = 0; j < std::min(size, 8); ++j) {
            const uintptr_t obj = Read<uintptr_t>(items + Layout::Array_data + sizeof(uintptr_t) * j, task_);
            if (!PtrOK(obj)) continue;
            const uintptr_t objClass = Read<uintptr_t>(obj + Layout::Il2CppObject_klass, task_);
            if (objClass == netClass || objClass == playerClass) return list;
        }
    }
    return 0;
}

uintptr_t Runtime::resolveStats(uintptr_t player) const {
    const uintptr_t klass = classAt(TypeInfo::PLAYER_AKE);
    const uintptr_t statsClass = classAt(TypeInfo::STATS_YLW);
    const uintptr_t field = findField(klass, statsClass);
    return fieldValue(player, field);
}

uintptr_t Runtime::resolveWeaponPart(uintptr_t player) const {
    const uintptr_t klass = classAt(TypeInfo::PLAYER_AKE);
    const uintptr_t weaponClass = classAt(TypeInfo::WEAPON_PART_NRK);
    return fieldValue(player, findField(klass, weaponClass));
}

uintptr_t Runtime::findFieldByTypeVarRecursive(uintptr_t klass, uintptr_t typeVarRva) const {
    const uintptr_t expectedType = TypeVarTarget(task_, base_, typeVarRva);
    if (!PtrOK(klass) || !PtrOK(expectedType)) return 0;
    uintptr_t cur = klass;
    for (int depth = 0; depth < 32 && PtrOK(cur); ++depth) {
        const uint16_t count = Read<uint16_t>(cur + Layout::Il2CppClass_field_count, task_);
        const uintptr_t fields = Read<uintptr_t>(cur + Layout::Il2CppClass_fields, task_);
        if (PtrOK(fields) && count > 0 && count <= 4096) {
            for (uint16_t i = 0; i < count; ++i) {
                const uintptr_t field = Read<uintptr_t>(fields + sizeof(uintptr_t) * i, task_);
                if (!PtrOK(field)) continue;
                if (Read<uintptr_t>(field + Layout::FieldInfo_type, task_) == expectedType) return field;
            }
        }
        cur = Read<uintptr_t>(cur + Layout::Il2CppClass_parent, task_);
    }
    return 0;
}

uint8_t Runtime::resolveTeam(uintptr_t weaponPart) const {
    if (!PtrOK(weaponPart)) return 0;
    const uintptr_t weaponPartClass = classAt(TypeInfo::WEAPON_PART_NRK);
    const uintptr_t contextField = findFieldByTypeVarRecursive(weaponPartClass, TypeVar::WEAPON_CONTEXT);
    if (!PtrOK(contextField)) return 0;
    const uintptr_t contextOff = Read<uintptr_t>(contextField + Layout::FieldInfo_offset, task_);
    if (contextOff > 0x100000) return 0;
    const uintptr_t contextClass = typeClassFromVar(TypeVar::WEAPON_CONTEXT);
    if (!PtrOK(contextClass)) return 0;
    const uintptr_t teamField = findFieldByNameRecursive(contextClass, "Team");
    if (!PtrOK(teamField)) return 0;
    const uintptr_t teamOff = Read<uintptr_t>(teamField + Layout::FieldInfo_offset, task_);
    if (teamOff > 0x100000) return 0;
    return Read<uint8_t>(weaponPart + contextOff + teamOff, task_);
}

bool Runtime::resolveHp(uintptr_t stats, uint16_t &hp, uint16_t &maxHp,
                        uint16_t &armor, uint16_t &maxArmor) const {
    if (!PtrOK(stats)) return false;
    hp = Read<uint16_t>(stats + Candidate::YLW_HP, task_);
    maxHp = Read<uint16_t>(stats + Candidate::YLW_MAX_HP, task_);
    armor = Read<uint16_t>(stats + Candidate::YLW_ARMOR, task_);
    maxArmor = Read<uint16_t>(stats + Candidate::YLW_MAX_ARMOR, task_);
    return maxHp > 0 && maxHp <= 1000 && hp <= maxHp &&
           armor <= 1000 && maxArmor <= 1000;
}

bool Runtime::resolveWeapon(uintptr_t weaponPart, uint8_t &weaponId, uint16_t &ammo) const {
    weaponId = 0;
    ammo = 0;
    if (!PtrOK(weaponPart)) return false;

    const uintptr_t wpClass = classAt(TypeInfo::WEAPON_PART_NRK);
    const uintptr_t ctxField = findFieldByTypeVarRecursive(wpClass, TypeVar::WEAPON_CONTEXT);
    if (!PtrOK(ctxField)) return false;
    const uintptr_t ctxOff = Read<uintptr_t>(ctxField + Layout::FieldInfo_offset, task_);
    if (ctxOff > 0x100000) return false;

    const uintptr_t ctxClass = typeClassFromVar(TypeVar::WEAPON_CONTEXT);
    if (!PtrOK(ctxClass)) return false;
    const uintptr_t activeField = findField(ctxClass, classAt(TypeInfo::WEAPON_INSTANCE_QJF));
    if (!PtrOK(activeField)) return false;
    const uintptr_t activeOff = Read<uintptr_t>(activeField + Layout::FieldInfo_offset, task_);
    if (activeOff > 0x100000) return false;
    const uintptr_t weapon = Read<uintptr_t>(weaponPart + ctxOff + activeOff, task_);
    if (!PtrOK(weapon)) return false;

    const uintptr_t weaponClass = classAt(TypeInfo::WEAPON_INSTANCE_QJF);
    const uintptr_t actualClass = Read<uintptr_t>(weapon + Layout::Il2CppObject_klass, task_);
    if (actualClass != weaponClass) return false;

    // The supplied 1.0.0 analysis identifies these as candidates. Keep the
    // numerical values isolated and require the expected object/class chain first.
    weaponId = Read<uint8_t>(weapon + Candidate::QJF_WEAPON_ID, task_);
    ammo = Read<uint16_t>(weapon + Candidate::QJF_AMMO, task_);
    return ammo <= 1000;
}

uintptr_t Runtime::resolveRootTransform(uintptr_t player) const {
    const uintptr_t playerClass = classAt(TypeInfo::PLAYER_AKE);
    const uintptr_t transformsClass = classAt(TypeInfo::TRANSFORMS_DWC);
    const uintptr_t transforms = fieldValue(player, findField(playerClass, transformsClass));
    if (!PtrOK(transforms)) return 0;

    const uintptr_t tClass = Read<uintptr_t>(transforms + Layout::Il2CppObject_klass);
    const uint16_t count = Read<uint16_t>(tClass + Layout::Il2CppClass_field_count, task_);
    const uintptr_t fields = Read<uintptr_t>(tClass + Layout::Il2CppClass_fields, task_);
    if (!PtrOK(fields) || count == 0 || count > 4096) return 0;

    for (uint16_t i = 0; i < count; ++i) {
        const uintptr_t field = Read<uintptr_t>(fields + sizeof(uintptr_t) * i, task_);
        if (!PtrOK(field)) continue;
        const uintptr_t type = Read<uintptr_t>(field + Layout::FieldInfo_type, task_);
        const uintptr_t fieldClass = PtrOK(type) ? Read<uintptr_t>(type, task_) : 0;
        if (!PtrOK(fieldClass)) continue;
        const std::string name = readCString(Read<uintptr_t>(fieldClass + Layout::Il2CppClass_name, task_));
        const std::string ns = readCString(Read<uintptr_t>(fieldClass + Layout::Il2CppClass_namespace, task_));
        if (name == "Transform" && ns == "UnityEngine") return fieldValue(transforms, field);
    }
    return 0;
}

Vector3 Runtime::resolvePosition(uintptr_t transform) const {
    // The supplied data validates Transform::GetPositionAndRotation_Injected,
    // but this external reader cannot directly invoke a target-process ICall.
    // Keep the existing transform-memory walker isolated here until an injected
    // call bridge is supplied; no old PlayerController offsets are used.
    if (!PtrOK(transform)) return {0,0,0};
    uintptr_t native = Read<uintptr_t>(transform + 0x10, task_);
    if (!PtrOK(native)) return {0,0,0};
    uintptr_t matrix = Read<uintptr_t>(native + 0x28, task_);
    if (!PtrOK(matrix)) return {0,0,0};
    int index = Read<int>(native + 0x30, task_);
    uintptr_t list = Read<uintptr_t>(matrix + 0x18, task_);
    uintptr_t indices = Read<uintptr_t>(matrix + 0x20, task_);
    if (!PtrOK(list) || !PtrOK(indices) || index < 0 || index > 100000) return {0,0,0};
    struct V4 { float x,y,z,w; };
    struct TM { V4 p,r,s; };
    TM self = Read<TM>(list + sizeof(TM) * (size_t)index, task_);
    return {self.p.x, self.p.y, self.p.z};
}

bool Runtime::collectPlayers(std::vector<PlayerSnapshot>& out) {
    out.clear();
    if (!ready_ || !PtrOK(world_)) return false;

    const uintptr_t worldClass = classAt(TypeInfo::CLIENTWORLD_NJH);
    const uintptr_t registryClass = classAt(TypeInfo::REGISTRY_GAT);
    const uintptr_t storeClass = classAt(TypeInfo::STORE_GZX);
    uintptr_t registry = fieldValue(world_, findField(worldClass, registryClass));
    uintptr_t storage = fieldValue(registry, findField(registryClass, storeClass));
    uintptr_t list = resolveAllObjectsList(storage);
    if (!PtrOK(list)) return false;

    const uintptr_t items = Read<uintptr_t>(list + Layout::List_items, task_);
    int size = Read<int>(list + Layout::List_size, task_);
    if (!PtrOK(items) || size <= 0 || size > 4096) return false;

    const uintptr_t playerClass = classAt(TypeInfo::PLAYER_AKE);
    for (int i = 0; i < size; ++i) {
        uintptr_t player = Read<uintptr_t>(items + Layout::Array_data + sizeof(uintptr_t) * i, task_);
        if (!PtrOK(player) || Read<uintptr_t>(player + Layout::Il2CppObject_klass, task_) != playerClass) continue;
        PlayerSnapshot p;
        p.object = player;
        p.stats = resolveStats(player);
        p.weaponPart = resolveWeaponPart(player);
        p.team = resolveTeam(p.weaponPart);
        p.alive = resolveHp(p.stats, p.hp, p.maxHp, p.armor, p.maxArmor) && p.hp > 0;
        resolveWeapon(p.weaponPart, p.weaponId, p.ammo);
        p.rootTransform = resolveRootTransform(player);
        if (p.rootTransform) p.position = resolvePosition(p.rootTransform);
        out.push_back(p);
    }

    // Local player resolution uses the supplied OwnerId/ActorId path only when
    // those fields are actually present; no old +0x40/+0x44/etc. offsets.
    localPlayer_ = 0;
    uintptr_t transport = fieldValue(world_, findField(worldClass, classAt(TypeInfo::TRANSPORT_HBU)));
    uintptr_t actor = fieldValue(transport, findField(classAt(TypeInfo::TRANSPORT_HBU), classAt(TypeInfo::ACTOR_STN)));
    uintptr_t actorIdField = findFieldByName(classAt(TypeInfo::ACTOR_STN), "ActorId");
    if (PtrOK(actor) && PtrOK(actorIdField)) {
        const uintptr_t actorIdOff = Read<uintptr_t>(actorIdField + Layout::FieldInfo_offset, task_);
        const uint32_t actorId = Read<uint32_t>(actor + actorIdOff, task_);
        const uintptr_t ownerField = findFieldByName(playerClass, "OwnerId");
        if (PtrOK(ownerField)) {
            const uintptr_t ownerOff = Read<uintptr_t>(ownerField + Layout::FieldInfo_offset, task_);
            for (auto &p : out) {
                if (Read<uint32_t>(p.object + ownerOff, task_) == actorId) {
                    localPlayer_ = p.object;
                    break;
                }
            }
        }
    }
    return true;
}
