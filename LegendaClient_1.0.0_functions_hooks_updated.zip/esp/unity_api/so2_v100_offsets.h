#pragma once
#include <cstdint>

// Standoff 2 1.0.0 / ARM64 validated data supplied with this project.
// All addresses are RVAs relative to the loaded UnityFramework/libunity image.
namespace SO2V100 {
namespace ICall {
constexpr uintptr_t Camera_get_main_Injected = 0x53653C4;
constexpr uintptr_t Camera_get_currentInternal_Injected = 0x53653E8;
constexpr uintptr_t Camera_get_fieldOfView_Injected = 0x5364FE4;
constexpr uintptr_t Camera_get_worldToCameraMatrix_Injected = 0x5365204;
constexpr uintptr_t Camera_get_projectionMatrix_Injected = 0x5365228;
constexpr uintptr_t Camera_WorldToScreenPoint_Injected = 0x5365268;
constexpr uintptr_t Camera_ScreenToWorldPoint_Injected = 0x53652FC;
constexpr uintptr_t Component_get_transform_Injected = 0x5371D30;
constexpr uintptr_t GameObject_get_transform_Injected = 0x53727CC;
constexpr uintptr_t Transform_GetPositionAndRotation_Injected = 0x53764E0;
constexpr uintptr_t Animator_GetBoneTransformInternal_Injected = 0x539569C;
constexpr uintptr_t Renderer_get_bounds_Injected = 0x53689D0;
constexpr uintptr_t Collider_get_bounds_Injected = 0x538B650;
constexpr uintptr_t GameObject_GetComponentsInternal_Injected = 0x5372370;
constexpr uintptr_t PhysicsScene_Internal_RaycastTest_Injected = 0x538BCF4;
constexpr uintptr_t PhysicsScene_Internal_Raycast_Injected = 0x538BD0C;
constexpr uintptr_t PhysicsScene_Internal_RaycastNonAlloc_Injected = 0x538BD24;
constexpr uintptr_t PhysicsScene_Query_SphereCast_Injected = 0x538BDBC;
constexpr uintptr_t PhysicsScene_Query_BoxCast_Injected = 0x538BE40;
}

namespace TypeInfo {
constexpr uintptr_t CLIENTWORLD_NJH = 0xC1C2DB8;
constexpr uintptr_t REGISTRY_GAT = 0xC1C0828;
constexpr uintptr_t STORE_GZX = 0xC1C0CE8;
constexpr uintptr_t PLAYER_AKE = 0xC1BEB30;
constexpr uintptr_t NETOBJECT_MFC = 0xC1C27C0;
constexpr uintptr_t TRANSFORMS_DWC = 0xC1BFC80;
constexpr uintptr_t PLAYER_BINDINGS = 0xC1DBA90;
constexpr uintptr_t MODEL_JGI = 0xC1C1840;
constexpr uintptr_t CHARACTER_BINDINGS = 0xC1B0F18;
constexpr uintptr_t BONES_DICTIONARY = 0xC1B0900;
constexpr uintptr_t HITBOX_COLLIDER = 0xC202E90;
constexpr uintptr_t STATS_YLW = 0xC1C6810;
constexpr uintptr_t UNTOUCHABLE_TBQ = 0xC1C4A78;
constexpr uintptr_t VISIBILITY_QDP = 0xC1C3BF0;
constexpr uintptr_t TRANSPORT_HBU = 0xC1C0D50;
constexpr uintptr_t ACTOR_STN = 0xC1C48D8;
constexpr uintptr_t WEAPON_PART_NRK = 0xC1C2F80;
constexpr uintptr_t WEAPON_INSTANCE_QJF = 0xC1C3D18;
constexpr uintptr_t WEAPON_PROVIDER_IJQ = 0xC1C1380;
constexpr uintptr_t WEAPON_DEFINITION = 0xC1EE058;
constexpr uintptr_t GUN_PARAMETERS = 0xC1B4AE8;
constexpr uintptr_t INPUT_MANAGER_ZNN = 0xC1C6DC8;
constexpr uintptr_t INPUT_COMMAND_OWV = 0xC1C3568;
constexpr uintptr_t CAMERA_COMPONENT_IOS = 0xC1C1498;
constexpr uintptr_t ROTATION_EIR = 0xC1BFF70;
constexpr uintptr_t CAMERA_CONTROLLER_NRL = 0xC1FA380;
constexpr uintptr_t NAVIGATION_NIP = 0xC1C2D98;
constexpr uintptr_t MOVEMENT_TOF = 0xC1C4D08;
constexpr uintptr_t GLOBAL_OPTIONS = 0xC1B4648;
constexpr uintptr_t ROOT_LIFETIME_SCOPE = 0xC1F57C8;
}

namespace TypeVar {
constexpr uintptr_t CHARACTER_BINDINGS = 0xC193710;
constexpr uintptr_t CLIENTWORLD_OPTIONS = 0xC193820;
constexpr uintptr_t GLOBAL_OPTIONS = 0xC194E00;
constexpr uintptr_t WEAPON_CONTEXT = 0xC197A28;
constexpr uintptr_t BUTTONINPUT_CONTAINER = 0xC1AD958;
constexpr uintptr_t CLIENTWORLD_FUNC = 0xC1A1AF0;
}

namespace Candidate {
constexpr uintptr_t YLW_HP = 0x10;
constexpr uintptr_t YLW_MAX_HP = 0x12;
constexpr uintptr_t YLW_ARMOR = 0x14;
constexpr uintptr_t YLW_MAX_ARMOR = 0x16;
constexpr uintptr_t NRK_WEAPON_CONTEXT = 0x30;
constexpr uintptr_t NRK_TEAM = 0x38;
constexpr uintptr_t NRK_ACTIVE_WEAPON = 0x78;
constexpr uintptr_t QJF_WEAPON_ID = 0x10;
constexpr uintptr_t QJF_AMMO = 0x54;
}

namespace Layout {
constexpr uintptr_t Il2CppObject_klass = 0x00;
constexpr uintptr_t Il2CppObject_monitor = 0x08;
constexpr uintptr_t Il2CppObject_fields = 0x10;
constexpr uintptr_t Il2CppClass_field_count = 0x58;
constexpr uintptr_t Il2CppClass_instance_size = 0x60;
constexpr uintptr_t Il2CppClass_fields = 0xC0;
constexpr uintptr_t Il2CppClass_namespace = 0xD8;
constexpr uintptr_t Il2CppClass_parent = 0xE8;
constexpr uintptr_t Il2CppClass_byval_arg = 0x138;
constexpr uintptr_t Il2CppClass_name = 0x198;
constexpr uintptr_t FieldInfo_name = 0x00;
constexpr uintptr_t FieldInfo_parent = 0x10;
constexpr uintptr_t FieldInfo_type = 0x18;
constexpr uintptr_t FieldInfo_offset = 0x20;
constexpr uintptr_t List_items = 0x10;
constexpr uintptr_t List_size = 0x18;
constexpr uintptr_t Array_data = 0x20;
}
}
