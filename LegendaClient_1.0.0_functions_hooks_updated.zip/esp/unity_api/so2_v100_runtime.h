#pragma once
#include <mach/mach.h>
#include <cstdint>
#include <vector>
#include <string>
#include "../helpers/Vector3.h"
#include "../helpers/pid.h"

namespace SO2V100 {

struct PlayerSnapshot {
    uintptr_t object = 0;
    uintptr_t stats = 0;
    uintptr_t weaponPart = 0;
    uintptr_t rootTransform = 0;
    uint16_t hp = 0;
    uint16_t maxHp = 0;
    uint8_t team = 0;
    bool alive = false;
    uint16_t armor = 0;
    uint16_t maxArmor = 0;
    uint8_t weaponId = 0;
    uint16_t ammo = 0;
    Vector3 position{0,0,0};
};

class Runtime {
public:
    bool initialize(task_t task, uintptr_t unityBase);
    void reset();
    bool ready() const { return ready_; }
    uintptr_t unityBase() const { return base_; }
    uintptr_t classAt(uintptr_t typeInfoRva) const;
    bool collectPlayers(std::vector<PlayerSnapshot>& out);
    uintptr_t localPlayer() const { return localPlayer_; }

private:
    task_t task_ = MACH_PORT_NULL;
    uintptr_t base_ = 0;
    uintptr_t world_ = 0;
    uintptr_t localPlayer_ = 0;
    bool ready_ = false;

    uintptr_t findObjectByClass(uintptr_t klass) const;
    uintptr_t findField(uintptr_t klass, uintptr_t expectedFieldClass) const;
    uintptr_t findFieldByNameRecursive(uintptr_t klass, const char *name) const;
    uintptr_t findFieldByTypeVarRecursive(uintptr_t klass, uintptr_t typeVarRva) const;
    uintptr_t typeClassFromVar(uintptr_t typeVarRva) const;
    uintptr_t findFieldByTypeVar(uintptr_t klass, uintptr_t typeVarRva) const;
    uintptr_t findFieldByName(uintptr_t klass, const char *name) const;
    uintptr_t fieldValue(uintptr_t object, uintptr_t field) const;
    uintptr_t resolveWorld();
    uintptr_t resolveAllObjectsList(uintptr_t storage) const;
    uintptr_t resolveRootTransform(uintptr_t player) const;
    uintptr_t resolveStats(uintptr_t player) const;
    uintptr_t resolveWeaponPart(uintptr_t player) const;
    uint8_t resolveTeam(uintptr_t weaponPart) const;
    bool resolveHp(uintptr_t stats, uint16_t &hp, uint16_t &maxHp,
                   uint16_t &armor, uint16_t &maxArmor) const;
    bool resolveWeapon(uintptr_t weaponPart, uint8_t &weaponId, uint16_t &ammo) const;
    Vector3 resolvePosition(uintptr_t transform) const;
    bool isReadable(uintptr_t p) const;
    std::string readCString(uintptr_t p, size_t maxLen = 128) const;
};

} // namespace SO2V100
