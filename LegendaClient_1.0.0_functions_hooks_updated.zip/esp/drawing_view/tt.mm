#import "esp.h"
#import "cfg.h"
#include "obfusheader.h"
#import "tt.h"
#include <string>
#include <vector>
#include <map>
#import "../../sources/UIView+SecureView.h"
#import <notify.h>

extern volatile bool esp_screenshot_safe;

static NSString *const kMenuPosPath   = @"/var/mobile/Library/Preferences/@x1work_menu_position.txt";
static NSString *const kMenuPosNotify = @"com.@x1work.menu_position_changed";

// Compact dark menu styled after the supplied reference screenshot.
// Function state/callbacks stay connected to the existing project variables.
static UIColor *TT_Bg(void)           { return [UIColor colorWithWhite:0.075 alpha:0.97]; }
static UIColor *TT_Header(void)       { return [UIColor colorWithWhite:0.105 alpha:0.98]; }
static UIColor *TT_Row(void)          { return [UIColor colorWithWhite:0.080 alpha:0.96]; }
static UIColor *TT_RowAlt(void)       { return [UIColor colorWithWhite:0.105 alpha:0.96]; }
static UIColor *TT_Divider(void)      { return [UIColor colorWithWhite:1.0 alpha:0.075]; }
static UIColor *TT_TextPrimary(void)  { return [UIColor colorWithWhite:0.98 alpha:1.0]; }
static UIColor *TT_TextSecondary(void){ return [UIColor colorWithWhite:0.72 alpha:1.0]; }
static UIColor *TT_Accent(void)       { return [UIColor colorWithRed:0.18 green:0.80 blue:0.43 alpha:1.0]; }
static UIColor *TT_Danger(void)       { return [UIColor colorWithRed:0.92 green:0.30 blue:0.34 alpha:1.0]; }

// Reference geometry: compact center card + vertical sidebar.
static const CGFloat kMenuW = 360.0;
static const CGFloat kMenuH = 286.0;
static const CGFloat kSidebarW = 106.0;
static const CGFloat kRowH = 36.0;
static const CGFloat kSideInset = 12.0;

typedef NS_ENUM(NSInteger, TTTab) {
    TT_TAB_AIM = 0,
    TT_TAB_VISUAL,
    TT_TAB_PLAYER,
    TT_TAB_CONFIG,
    TT_TAB_SKINS,
    TT_TAB_OTHER,
    TT_TAB_COUNT
};

#pragma mark - MenuView

@interface MenuView () <UIGestureRecognizerDelegate>
@end

@implementation MenuView {
    UIVisualEffectView   *_blurView;
    UIView               *_headerView;
    UIImageView          *_headerLogoView;
    UILabel              *_headerLabel;
    UILabel              *_headerSubtitleLabel;

    UIView               *_tabControl; // vertical tab container
    UIButton             *_tabButtons[TT_TAB_COUNT];
    UIScrollView         *_scrollViews[TT_TAB_COUNT];

    CGSize                _expandedSize;
    NSInteger             _currentTab;

    // Toggles (UISwitch, one per feature).
    UISwitch *_swBox, *_swBoxOutline, *_swBoxFill, *_swBoxCorner, *_swBox3D;
    UISwitch *_swLine, *_swLineOutline, *_swTeam;
    UISwitch *_swName, *_swNameOutline, *_swHealth, *_swHealthBar, *_swHealthBarOutline;
    UISwitch *_swWeapon, *_swWeaponIcon, *_swPlatform, *_swAvatar;
    UISwitch *_swSkeleton, *_swSkeletonOccluded;
    UISwitch *_swViewmodel;
    UISwitch *_swInvisible, *_swAddScore, *_swInfAmmo, *_swNoSpread, *_swAirJump;
    UISwitch *_swFastKnife, *_swWallshot, *_swFireRate, *_swRCS;
    UISwitch *_swAimbot, *_swTriggerbot, *_swAimFov, *_swVisCheck, *_swFireCheck;
    UISwitch *_swKnifeBot, *_swAimTeam;
    UISwitch *_swAlwaysHead, *_swFreezeLocal, *_swFreezeEnemies, *_swAntiFlash, *_swAntiMolotov;
    UISwitch *_swOverlay;

    // Sliders (standard UISlider).
    UISlider *_sldSmooth, *_sldFov, *_sldTriggerDelay;
    UISlider *_sldRCSH, *_sldRCSV;
    UISlider *_sldVmX, *_sldVmY, *_sldVmZ;
    UILabel  *_lblSmooth, *_lblFov, *_lblTriggerDelay;
    UILabel  *_lblRCSH, *_lblRCSV;
    UILabel  *_lblVmX, *_lblVmY, *_lblVmZ;

    UISegmentedControl *_boneSelector;

    // Config tab.
    UIScrollView *_configList;
    CGFloat       _configListYCursor;

    // Skins tab.
    UIScrollView *_skinList;
    NSTimer      *_skinTimer;
    std::vector<std::pair<int, uintptr_t>> _ownedSkinsInfo;
    std::vector<std::pair<int, std::string>> _allSkinsList;
    int           _selectedOwnedIdx;
    int           _selectedReplaceIdx;

    // Position sync.
    NSTimer      *_positionTimer;
    NSInteger     _lastAppliedPosition;

    // Manual touch routing.
    UIView       *_activeTouchView;
    UIScrollView *_activeScrollView;
    UISlider     *_activeSlider;
    CGPoint       _touchStartPoint;
    CGPoint       _scrollStartOffset;
    BOOL          _scrolling;
}

#pragma mark - Init

- (instancetype)initWithFrame:(CGRect)frame {
    // Caller may pass anything; the dark landscape layout is a fixed size.
    frame.size = CGSizeMake(kMenuW, kMenuH);
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _expandedSize  = frame.size;
    _lastAppliedPosition = -1;
    _selectedOwnedIdx = -1;
    _selectedReplaceIdx = -1;

    self.backgroundColor = TT_Bg();
    self.layer.cornerRadius = 16.0;
    self.layer.borderWidth = 0.5;
    self.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.08].CGColor;
    self.clipsToBounds = YES;
    self.userInteractionEnabled = YES;

    // Blur underlay for depth on translucent backgrounds. Kept under the row
    // strip so scrolling reads over solid colour, not shimmering blur.
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
    _blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
    _blurView.frame = self.bounds;
    _blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _blurView.userInteractionEnabled = NO;
    [self addSubview:_blurView];

    [self buildHeader];
    [self buildTabBar];
    [self buildAllTabs];

    _currentTab = TT_TAB_AIM;
    [self showTab:_currentTab];

    [self showViewForCapture];
    self.hidden = YES; // Start hidden; toggle with three 3-finger taps.

    // Position: file at kMenuPosPath, poked via kMenuPosNotify from the loader
    // UI. Poll as a safety net -- notify_register_dispatch loses events when
    // the process is backgrounded, and losing the position setting is worse
    // than the 1-Hz poll cost.
    _positionTimer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                      target:self
                                                    selector:@selector(pollMenuPosition)
                                                    userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_positionTimer forMode:NSRunLoopCommonModes];

    int token = 0;
    notify_register_dispatch(kMenuPosNotify.UTF8String, &token,
                             dispatch_get_main_queue(), ^(int t) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self applyMenuPosition]; });
    });

    [self applyMenuPosition];
    return self;
}

- (void)dealloc {
    [_skinTimer invalidate];     _skinTimer = nil;
    [_positionTimer invalidate]; _positionTimer = nil;
}

#pragma mark - Sidebar header

- (void)buildHeader {
    _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kSidebarW, kMenuH)];
    _headerView.backgroundColor = TT_Header();
    _headerView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    [self addSubview:_headerView];

    _headerLogoView = [[UIImageView alloc] initWithFrame:CGRectMake((kSidebarW - 44.0) / 2.0, 10, 44, 44)];
    _headerLogoView.image = [UIImage imageNamed:@"logo.png"];
    _headerLogoView.contentMode = UIViewContentModeScaleAspectFit;
    [_headerView addSubview:_headerLogoView];

    UIView *divider = [[UIView alloc] initWithFrame:CGRectMake(kSidebarW - 0.5, 0, 0.5, kMenuH)];
    divider.backgroundColor = TT_Divider();
    divider.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    divider.tag = 7713;
    [self addSubview:divider];


}

#pragma mark - Vertical tabs

- (void)buildTabBar {
    _tabControl = [[UIView alloc] initWithFrame:CGRectMake(0, 58, kSidebarW, kMenuH - 58)];
    _tabControl.backgroundColor = UIColor.clearColor;
    [self addSubview:_tabControl];

    NSArray<NSString *> *titles = @[@"Aimbot", @"Visuals", @"Player", @"Load", @"Skins", @"Misc"];
    CGFloat buttonH = 36.0;
    for (NSInteger i = 0; i < TT_TAB_COUNT; i++) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        b.frame = CGRectMake(0, i * buttonH, kSidebarW, buttonH);
        b.tag = i;
        [b setTitle:titles[i] forState:UIControlStateNormal];
        [b setTitleColor:TT_TextPrimary() forState:UIControlStateNormal];
        b.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
        b.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        b.contentEdgeInsets = UIEdgeInsetsMake(0, 15, 0, 5);
        [b addTarget:self action:@selector(tabButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        [_tabControl addSubview:b];
        _tabButtons[i] = b;
    }
}

- (void)tabButtonTapped:(UIButton *)sender {
    [self showTab:sender.tag];
}

- (void)showTab:(NSInteger)tab {
    if (tab < 0 || tab >= TT_TAB_COUNT) return;
    _currentTab = tab;

    for (int i = 0; i < TT_TAB_COUNT; i++) {
        _scrollViews[i].hidden = (i != tab);
        UIButton *b = _tabButtons[i];
        BOOL selected = (i == tab);
        b.backgroundColor = selected ? [UIColor colorWithWhite:0.17 alpha:1.0] : UIColor.clearColor;
        b.titleLabel.font = [UIFont systemFontOfSize:12 weight:(selected ? UIFontWeightMedium : UIFontWeightRegular)];
    }

    if (tab == TT_TAB_SKINS) {
        [self refreshSkinList];
    } else {
        [_skinTimer invalidate];
        _skinTimer = nil;
    }
    if (tab == TT_TAB_CONFIG) [self refreshConfigList];
}

#pragma mark - Tab construction

- (UIScrollView *)makeScrollHost {
    UIScrollView *sv = [[UIScrollView alloc] initWithFrame:
        CGRectMake(kSidebarW, 0, kMenuW - kSidebarW, kMenuH)];
    sv.backgroundColor = [UIColor clearColor];
    sv.showsVerticalScrollIndicator = NO;
    sv.showsHorizontalScrollIndicator = NO;
    // Scrolling is driven by MenuView's own touch handlers via contentOffset.
    // UIScrollView's gesture machinery is kept out of the HUD touch path.
    sv.scrollEnabled = NO;
    sv.hidden = YES;
    sv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    if (@available(iOS 11.0, *)) sv.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    [self addSubview:sv];
    return sv;
}

- (void)buildAllTabs {
    for (int i = 0; i < TT_TAB_COUNT; i++) {
        _scrollViews[i] = [self makeScrollHost];
    }

    [self buildAimTab:_scrollViews[TT_TAB_AIM]];
    [self buildVisualTab:_scrollViews[TT_TAB_VISUAL]];
    [self buildPlayerTab:_scrollViews[TT_TAB_PLAYER]];
    [self buildConfigTab:_scrollViews[TT_TAB_CONFIG]];
    [self buildSkinsTab:_scrollViews[TT_TAB_SKINS]];
    [self buildOtherTab:_scrollViews[TT_TAB_OTHER]];
}

#pragma mark - Row helpers

- (void)addSectionHeader:(NSString *)title toHost:(UIScrollView *)host atY:(CGFloat *)y {
    UILabel *h = [[UILabel alloc] initWithFrame:CGRectMake(kSideInset, *y + 5, host.bounds.size.width - kSideInset * 2 - 20, 16)];
    h.text = title;
    h.font = [UIFont systemFontOfSize:10 weight:UIFontWeightSemibold];
    h.textColor = [UIColor colorWithWhite:0.58 alpha:1.0];
    [host addSubview:h];
    *y += 23;
}

- (UISwitch *)addSwitchRow:(NSString *)title
                    onFlag:(BOOL)initial
                    action:(SEL)action
                    toHost:(UIScrollView *)host
                    column:(int)col
                       atY:(CGFloat)y
{
    (void)col;
    CGFloat rowW = host.bounds.size.width - kSideInset * 2;
    UIView *row = [[UIView alloc] initWithFrame:CGRectMake(kSideInset, y, rowW, kRowH)];
    row.backgroundColor = UIColor.clearColor;
    [host addSubview:row];

    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rowW - 58, kRowH)];
    lbl.text = title;
    lbl.textColor = TT_TextPrimary();
    lbl.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    [row addSubview:lbl];

    UISwitch *sw = [[UISwitch alloc] init];
    sw.transform = CGAffineTransformMakeScale(0.75, 0.75);
    CGSize ss = sw.frame.size;
    sw.frame = CGRectMake(rowW - ss.width + 5, (kRowH - ss.height) / 2.0, ss.width, ss.height);
    sw.onTintColor = TT_Accent();
    if (@available(iOS 13.0, *)) sw.thumbTintColor = [UIColor whiteColor];
    sw.on = initial;
    [sw addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    [row addSubview:sw];

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, kRowH - 0.5, rowW, 0.5)];
    line.backgroundColor = TT_Divider();
    [row addSubview:line];
    return sw;
}

- (UISlider *)addSliderRow:(NSString *)title
                       min:(float)mn
                       max:(float)mx
                     value:(float)val
                    format:(NSString *)fmt
                     label:(UILabel * __strong *)outLabel
                    action:(SEL)action
                    toHost:(UIScrollView *)host
                       atY:(CGFloat)y
{
    CGFloat rowW = host.bounds.size.width - kSideInset * 2;
    UIView *row = [[UIView alloc] initWithFrame:CGRectMake(kSideInset, y, rowW, 48)];
    row.backgroundColor = UIColor.clearColor;
    [host addSubview:row];

    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rowW - 74, 20)];
    lbl.text = title;
    lbl.textColor = TT_TextPrimary();
    lbl.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    [row addSubview:lbl];

    UILabel *val_l = [[UILabel alloc] initWithFrame:CGRectMake(rowW - 74, 0, 74, 20)];
    val_l.text = [NSString stringWithFormat:fmt, val];
    val_l.textColor = TT_TextPrimary();
    val_l.textAlignment = NSTextAlignmentRight;
    val_l.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightRegular];
    [row addSubview:val_l];
    if (outLabel) *outLabel = val_l;

    UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(0, 20, rowW, 24)];
    slider.minimumValue = mn;
    slider.maximumValue = mx;
    slider.value = val;
    slider.minimumTrackTintColor = TT_Accent();
    slider.maximumTrackTintColor = [UIColor colorWithWhite:1 alpha:0.45];
    [slider addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    [row addSubview:slider];
    return slider;
}

- (UIButton *)addButton:(NSString *)title toHost:(UIView *)host
                  frame:(CGRect)f style:(int)style action:(SEL)action
{
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = f;
    b.layer.cornerRadius = 6.0;
    b.clipsToBounds = YES;
    b.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIColor *bg = TT_Accent();
    if (style == 1) bg = TT_Danger();
    else if (style == 2) bg = [UIColor colorWithWhite:0.24 alpha:1.0];
    b.backgroundColor = bg;
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [host addSubview:b];
    return b;
}

- (void)finalizeHost:(UIScrollView *)host atY:(CGFloat)y {
    host.contentSize = CGSizeMake(host.bounds.size.width, y + 12);
}

#pragma mark - AIM tab

- (void)buildAimTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"Aimbot" toHost:host atY:&y];

    _swAimbot = [self addSwitchRow:@(OBF("Aimbot")) onFlag:aimbot_enabled action:@selector(aimbotChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swTriggerbot = [self addSwitchRow:@(OBF("Triggerbot")) onFlag:aimbot_triggerbot action:@selector(triggerbotChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAimFov = [self addSwitchRow:@(OBF("Draw FOV")) onFlag:aimbot_fov_visible action:@selector(aimFovChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swVisCheck = [self addSwitchRow:@(OBF("Visibility Check")) onFlag:aimbot_visible_check action:@selector(visCheckChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swFireCheck = [self addSwitchRow:@(OBF("Fire Check")) onFlag:aimbot_shooting_check action:@selector(fireCheckChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swKnifeBot = [self addSwitchRow:@(OBF("Knife Bot")) onFlag:aimbot_knife_bot action:@selector(knifeBotChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAimTeam = [self addSwitchRow:@(OBF("Team Check")) onFlag:aimbot_team_check action:@selector(aimTeamChanged:) toHost:host column:0 atY:y]; y += kRowH + 6;

    [self addSectionHeader:@"Aimbot Bone" toHost:host atY:&y];
    _boneSelector = [[UISegmentedControl alloc] initWithItems:@[@(OBF("Head")), @(OBF("Neck")), @(OBF("Spine")), @(OBF("Hip"))]];
    _boneSelector.frame = CGRectMake(kSideInset, y, host.bounds.size.width - kSideInset * 2, 28);
    _boneSelector.selectedSegmentIndex = aimbot_bone_index;
    if (@available(iOS 13.0, *)) {
        _boneSelector.selectedSegmentTintColor = TT_Accent();
        _boneSelector.backgroundColor = [UIColor colorWithWhite:0.30 alpha:0.75];
    }
    [_boneSelector setTitleTextAttributes:@{ NSForegroundColorAttributeName: TT_TextSecondary(), NSFontAttributeName:[UIFont systemFontOfSize:10] } forState:UIControlStateNormal];
    [_boneSelector setTitleTextAttributes:@{ NSForegroundColorAttributeName: [UIColor whiteColor], NSFontAttributeName:[UIFont systemFontOfSize:10 weight:UIFontWeightSemibold] } forState:UIControlStateSelected];
    [_boneSelector addTarget:self action:@selector(boneChanged:) forControlEvents:UIControlEventValueChanged];
    [host addSubview:_boneSelector];
    y += 38;

    _sldFov = [self addSliderRow:@(OBF("Aimbot FOV")) min:10.0f max:360.0f value:aimbot_fov format:@"%.0f" label:&_lblFov action:@selector(fovChanged:) toHost:host atY:y]; y += 50;
    _sldSmooth = [self addSliderRow:@(OBF("Aimbot Smooth")) min:0.0f max:20.0f value:aimbot_smooth format:@"%.1f" label:&_lblSmooth action:@selector(smoothChanged:) toHost:host atY:y]; y += 50;
    _sldTriggerDelay = [self addSliderRow:@(OBF("Trigger Delay")) min:0.01f max:1.0f value:aimbot_trigger_delay format:@"%.2f" label:&_lblTriggerDelay action:@selector(triggerDelayChanged:) toHost:host atY:y]; y += 50;

    [self finalizeHost:host atY:y];
}

#pragma mark - VISUAL tab

- (void)buildVisualTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"Visuals" toHost:host atY:&y];

    _swBox = [self addSwitchRow:@(OBF("Box 2D")) onFlag:esp_box_enabled action:@selector(boxChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swBoxOutline = [self addSwitchRow:@(OBF("Box Outline")) onFlag:esp_box_outline action:@selector(boxOutlineChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swBoxFill = [self addSwitchRow:@(OBF("Box Fill")) onFlag:esp_box_fill action:@selector(boxFillChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swBoxCorner = [self addSwitchRow:@(OBF("Box Corner")) onFlag:esp_box_corner action:@selector(boxCornerChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swBox3D = [self addSwitchRow:@(OBF("Box 3D")) onFlag:esp_box_3d action:@selector(box3DChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swLine = [self addSwitchRow:@(OBF("Line")) onFlag:esp_line_enabled action:@selector(lineChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swLineOutline = [self addSwitchRow:@(OBF("Line Outline")) onFlag:esp_line_outline action:@selector(lineOutlineChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swTeam = [self addSwitchRow:@(OBF("Team Check")) onFlag:esp_team_check action:@selector(teamChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swName = [self addSwitchRow:@(OBF("Name")) onFlag:esp_name_enabled action:@selector(nameChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swNameOutline = [self addSwitchRow:@(OBF("Name Outline")) onFlag:esp_name_outline action:@selector(nameOutlineChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swHealth = [self addSwitchRow:@(OBF("HP Number")) onFlag:esp_health_enabled action:@selector(healthChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swHealthBar = [self addSwitchRow:@(OBF("HP Bar")) onFlag:esp_health_bar_enabled action:@selector(healthBarChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swHealthBarOutline = [self addSwitchRow:@(OBF("Bar Outline")) onFlag:esp_health_bar_outline action:@selector(healthBarOutlineChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swWeapon = [self addSwitchRow:@(OBF("Weapon")) onFlag:esp_weapon_enabled action:@selector(weaponChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swWeaponIcon = [self addSwitchRow:@(OBF("Weapon Icon")) onFlag:esp_weapon_icon_enabled action:@selector(weaponIconChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swPlatform = [self addSwitchRow:@(OBF("Platform")) onFlag:esp_platform_enabled action:@selector(platformChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAvatar = [self addSwitchRow:@(OBF("Avatars")) onFlag:esp_avatar_enabled action:@selector(avatarChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swSkeleton = [self addSwitchRow:@(OBF("Skeleton")) onFlag:esp_skeleton_enabled action:@selector(skeletonChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swSkeletonOccluded = [self addSwitchRow:@(OBF("Occlusion BP")) onFlag:esp_skeleton_occluded action:@selector(skeletonOccludedChanged:) toHost:host column:0 atY:y]; y += kRowH + 6;

    [self addSectionHeader:@"Viewmodel" toHost:host atY:&y];
    _swViewmodel = [self addSwitchRow:@(OBF("Viewmodel")) onFlag:viewmodel_enabled action:@selector(viewmodelChanged:) toHost:host column:0 atY:y]; y += kRowH + 4;
    _sldVmX = [self addSliderRow:@(OBF("View X")) min:-10.0f max:10.0f value:viewmodel_x format:@"%.1f" label:&_lblVmX action:@selector(vmXChanged:) toHost:host atY:y]; y += 50;
    _sldVmY = [self addSliderRow:@(OBF("View Y")) min:-10.0f max:10.0f value:viewmodel_y format:@"%.1f" label:&_lblVmY action:@selector(vmYChanged:) toHost:host atY:y]; y += 50;
    _sldVmZ = [self addSliderRow:@(OBF("View Z")) min:-10.0f max:10.0f value:viewmodel_z format:@"%.1f" label:&_lblVmZ action:@selector(vmZChanged:) toHost:host atY:y]; y += 50;

    [self finalizeHost:host atY:y];
}

#pragma mark - PLAYER tab

- (void)buildPlayerTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"Player" toHost:host atY:&y];

    _swInvisible = [self addSwitchRow:@(OBF("Invisible")) onFlag:esp_invisible action:@selector(invisibleChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAddScore = [self addSwitchRow:@(OBF("Add Score")) onFlag:esp_addscore action:@selector(addScoreChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swInfAmmo = [self addSwitchRow:@(OBF("Inf Ammo")) onFlag:esp_inf_ammo action:@selector(infAmmoChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swNoSpread = [self addSwitchRow:@(OBF("No Spread")) onFlag:esp_no_spread action:@selector(noSpreadChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAirJump = [self addSwitchRow:@(OBF("Bunny Hop")) onFlag:esp_air_jump action:@selector(airJumpChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swFastKnife = [self addSwitchRow:@(OBF("Fast Knife")) onFlag:esp_fast_knife action:@selector(fastKnifeChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swWallshot = [self addSwitchRow:@(OBF("Wallshot")) onFlag:esp_wallshot action:@selector(wallshotChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swFireRate = [self addSwitchRow:@(OBF("Fire Rate")) onFlag:esp_fire_rate action:@selector(fireRateChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swRCS = [self addSwitchRow:@(OBF("RCS")) onFlag:esp_rcs_enabled action:@selector(rcsChanged:) toHost:host column:0 atY:y]; y += kRowH + 7;

    [self addSectionHeader:@"New Player functions" toHost:host atY:&y];
    _swAlwaysHead = [self addSwitchRow:@(OBF("Always Head / Hitbox")) onFlag:player_always_head action:@selector(alwaysHeadChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swFreezeLocal = [self addSwitchRow:@(OBF("Freeze Local")) onFlag:player_freeze_local action:@selector(freezeLocalChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swFreezeEnemies = [self addSwitchRow:@(OBF("Freeze Enemies")) onFlag:player_freeze_enemies action:@selector(freezeEnemiesChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAntiFlash = [self addSwitchRow:@(OBF("Anti Flash")) onFlag:player_anti_flash action:@selector(antiFlashChanged:) toHost:host column:0 atY:y]; y += kRowH;
    _swAntiMolotov = [self addSwitchRow:@(OBF("Anti Molotov")) onFlag:player_anti_molotov action:@selector(antiMolotovChanged:) toHost:host column:0 atY:y]; y += kRowH + 7;

    [self addSectionHeader:@"Tuning" toHost:host atY:&y];
    _sldRCSH = [self addSliderRow:@(OBF("RCS H")) min:0.0f max:10.0f value:esp_rcs_h format:@"%.1f" label:&_lblRCSH action:@selector(rcsHChanged:) toHost:host atY:y]; y += 50;
    _sldRCSV = [self addSliderRow:@(OBF("RCS V")) min:0.0f max:10.0f value:esp_rcs_v format:@"%.1f" label:&_lblRCSV action:@selector(rcsVChanged:) toHost:host atY:y]; y += 50;

    [self finalizeHost:host atY:y];
}

#pragma mark - CONFIG tab

- (void)buildConfigTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"CONFIGS" toHost:host atY:&y];

    CGFloat totalW = host.bounds.size.width - kSideInset * 2;
    CGFloat bw = (totalW - 12) / 3.0;
    [self addButton:@(OBF("Create")) toHost:host frame:CGRectMake(kSideInset,          y, bw, 30) style:0 action:@selector(createConfigFlow)];
    [self addButton:@(OBF("Load"))   toHost:host frame:CGRectMake(kSideInset + bw + 6, y, bw, 30) style:0 action:@selector(loadConfigFlow)];
    [self addButton:@(OBF("Delete")) toHost:host frame:CGRectMake(kSideInset + (bw + 6) * 2, y, bw, 30) style:1 action:@selector(deleteConfigFlow)];
    y += 38;

    // Inner scroll for the list -- lets the buttons stay pinned while the list
    // grows. Frame from y down to the bottom of the tab area.
    CGFloat listH = host.bounds.size.height - y - 8;
    if (listH < 60) listH = 60;
    _configList = [[UIScrollView alloc] initWithFrame:CGRectMake(kSideInset, y, totalW, listH)];
    _configList.backgroundColor = TT_Row();
    _configList.layer.cornerRadius = 6.0;
    _configList.showsVerticalScrollIndicator = NO;
    _configList.scrollEnabled = NO;
    [host addSubview:_configList];
    y += listH + 4;

    [self finalizeHost:host atY:y];
    [self refreshConfigList];
}

#pragma mark - SKINS tab

- (void)buildSkinsTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"SKIN CHANGER" toHost:host atY:&y];

    CGFloat totalW = host.bounds.size.width - kSideInset * 2;
    CGFloat listH  = host.bounds.size.height - y - 12;
    if (listH < 60) listH = 60;

    _skinList = [[UIScrollView alloc] initWithFrame:CGRectMake(kSideInset, y, totalW, listH)];
    _skinList.backgroundColor = TT_Row();
    _skinList.layer.cornerRadius = 6.0;
    _skinList.showsVerticalScrollIndicator = NO;
    _skinList.scrollEnabled = NO;
    [host addSubview:_skinList];
    y += listH + 4;

    // The skin manager keeps polling the game process for the inventory even
    // when the tab is hidden -- 1 Hz. Trims down cheaply when the game isn't
    // running (early return inside refreshSkinList).
    _skinTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self
                                                selector:@selector(refreshSkinList)
                                                userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_skinTimer forMode:NSRunLoopCommonModes];

    [self finalizeHost:host atY:y];
}

#pragma mark - OTHER tab

- (void)buildOtherTab:(UIScrollView *)host {
    CGFloat y = 4;
    [self addSectionHeader:@"OVERLAY" toHost:host atY:&y];
    _swOverlay = [self addSwitchRow:@(OBF("Screenshot Safe")) onFlag:esp_screenshot_safe
                             action:@selector(overlayChanged:) toHost:host column:0 atY:y];
    y += kRowH + 8;

    UILabel *hint = [[UILabel alloc] initWithFrame:
        CGRectMake(kSideInset, y, host.bounds.size.width - kSideInset * 2, 40)];
    hint.numberOfLines = 0;
    hint.text = @(OBF("Screenshot Safe hides the HUD from screen recording and screenshots."));
    hint.textColor = TT_TextSecondary();
    hint.font = [UIFont systemFontOfSize:11];
    [host addSubview:hint];
    y += 44;

    [self finalizeHost:host atY:y];
}

#pragma mark - Toggle callbacks

// UISwitch fires with the *new* value already applied to sw.on, so we just
// mirror it into the extern volatile.
- (void)aimbotChanged:(UISwitch *)s     { aimbot_enabled        = s.on; }
- (void)triggerbotChanged:(UISwitch *)s { aimbot_triggerbot     = s.on; }
- (void)aimFovChanged:(UISwitch *)s     { aimbot_fov_visible    = s.on; }
- (void)visCheckChanged:(UISwitch *)s   { aimbot_visible_check  = s.on; }
- (void)fireCheckChanged:(UISwitch *)s  { aimbot_shooting_check = s.on; }
- (void)knifeBotChanged:(UISwitch *)s   { aimbot_knife_bot      = s.on; }
- (void)aimTeamChanged:(UISwitch *)s    { aimbot_team_check     = s.on; }

- (void)boxChanged:(UISwitch *)s        { esp_box_enabled = s.on;
    if (!esp_box_enabled) [[NSNotificationCenter defaultCenter] postNotificationName:@"ESPClearBoxes" object:nil]; }
- (void)boxOutlineChanged:(UISwitch *)s { esp_box_outline = s.on; }
- (void)boxFillChanged:(UISwitch *)s    { esp_box_fill    = s.on; }
- (void)boxCornerChanged:(UISwitch *)s  { esp_box_corner  = s.on; }
- (void)box3DChanged:(UISwitch *)s      { esp_box_3d      = s.on; }
- (void)lineChanged:(UISwitch *)s       { esp_line_enabled = s.on; }
- (void)lineOutlineChanged:(UISwitch *)s{ esp_line_outline = s.on; }
- (void)teamChanged:(UISwitch *)s       { esp_team_check = s.on; }
- (void)nameChanged:(UISwitch *)s       { esp_name_enabled = s.on; }
- (void)nameOutlineChanged:(UISwitch *)s{ esp_name_outline = s.on; }
- (void)healthChanged:(UISwitch *)s     { esp_health_enabled = s.on; }
- (void)healthBarChanged:(UISwitch *)s  { esp_health_bar_enabled = s.on; }
- (void)healthBarOutlineChanged:(UISwitch *)s { esp_health_bar_outline = s.on; }
- (void)weaponChanged:(UISwitch *)s     { esp_weapon_enabled = s.on; }
- (void)weaponIconChanged:(UISwitch *)s { esp_weapon_icon_enabled = s.on; }
- (void)platformChanged:(UISwitch *)s   { esp_platform_enabled = s.on; }
- (void)avatarChanged:(UISwitch *)s     { esp_avatar_enabled = s.on; }
- (void)skeletonChanged:(UISwitch *)s   { esp_skeleton_enabled = s.on;
    if (!esp_skeleton_enabled) [[NSNotificationCenter defaultCenter] postNotificationName:@"ESPClearBoxes" object:nil]; }
- (void)skeletonOccludedChanged:(UISwitch *)s { esp_skeleton_occluded = s.on; }
- (void)viewmodelChanged:(UISwitch *)s  { viewmodel_enabled = s.on; }

- (void)invisibleChanged:(UISwitch *)s  { esp_invisible = s.on; }
- (void)addScoreChanged:(UISwitch *)s   { esp_addscore  = s.on; }
- (void)infAmmoChanged:(UISwitch *)s    { esp_inf_ammo  = s.on; }
- (void)noSpreadChanged:(UISwitch *)s   { esp_no_spread = s.on; }
- (void)airJumpChanged:(UISwitch *)s    { esp_air_jump  = s.on; }
- (void)fastKnifeChanged:(UISwitch *)s  { esp_fast_knife = s.on; }
- (void)wallshotChanged:(UISwitch *)s   { esp_wallshot  = s.on; }
- (void)fireRateChanged:(UISwitch *)s   { esp_fire_rate = s.on; }
- (void)rcsChanged:(UISwitch *)s        { esp_rcs_enabled = s.on; }
- (void)alwaysHeadChanged:(UISwitch *)s { player_always_head = s.on; }
- (void)freezeLocalChanged:(UISwitch *)s { player_freeze_local = s.on; }
- (void)freezeEnemiesChanged:(UISwitch *)s { player_freeze_enemies = s.on; }
- (void)antiFlashChanged:(UISwitch *)s { player_anti_flash = s.on; }
- (void)antiMolotovChanged:(UISwitch *)s { player_anti_molotov = s.on; }

- (void)overlayChanged:(UISwitch *)s {
    esp_screenshot_safe = s.on;
    if (self.superview) [self.superview hideViewFromCapture:esp_screenshot_safe];
    else                [self hideViewFromCapture:esp_screenshot_safe];
}

#pragma mark - Slider callbacks

- (void)smoothChanged:(UISlider *)s        { aimbot_smooth        = s.value; _lblSmooth.text        = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)fovChanged:(UISlider *)s           { aimbot_fov           = s.value; _lblFov.text           = [NSString stringWithFormat:@"%.0f", s.value]; }
- (void)triggerDelayChanged:(UISlider *)s  { aimbot_trigger_delay = s.value; _lblTriggerDelay.text  = [NSString stringWithFormat:@"%.2f", s.value]; }
- (void)rcsHChanged:(UISlider *)s          { esp_rcs_h            = s.value; _lblRCSH.text          = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)rcsVChanged:(UISlider *)s          { esp_rcs_v            = s.value; _lblRCSV.text          = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)vmXChanged:(UISlider *)s           { viewmodel_x          = s.value; _lblVmX.text           = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)vmYChanged:(UISlider *)s           { viewmodel_y          = s.value; _lblVmY.text           = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)vmZChanged:(UISlider *)s           { viewmodel_z          = s.value; _lblVmZ.text           = [NSString stringWithFormat:@"%.1f", s.value]; }
- (void)boneChanged:(UISegmentedControl *)s{ aimbot_bone_index    = (int)s.selectedSegmentIndex; }

#pragma mark - Legacy public API (esp.h)

// These live in esp.h @interface MenuView, so the compiler enforces they
// exist. Nothing calls them now that toggles live on UISwitch controls;
// keeping them as no-ops preserves the header contract.
- (void)boxTapped  {}
- (void)lineTapped {}
- (void)handlePan:(UIPanGestureRecognizer *)gesture {}
- (void)centerMenu { [self applyMenuPosition]; }

#pragma mark - Config list

- (void)refreshConfigList {
    if (!_configList) return;
    for (UIView *v in [_configList.subviews copy]) [v removeFromSuperview];

    NSArray *configs = cfg_get_list();
    CGFloat y = 6;
    CGFloat rowW = _configList.bounds.size.width - 12;
    if (configs.count == 0) {
        UILabel *empty = [[UILabel alloc] initWithFrame:CGRectMake(6, y, rowW, 26)];
        empty.text = @(OBF("No configs saved"));
        empty.font = [UIFont italicSystemFontOfSize:12];
        empty.textColor = TT_TextSecondary();
        [_configList addSubview:empty];
        y += 30;
    } else {
        for (NSString *name in configs) {
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(6, y, rowW, 28)];
            lbl.text = [NSString stringWithFormat:@"  %@", name];
            lbl.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
            lbl.textColor = TT_TextPrimary();
            BOOL selected = [name isEqualToString:esp_selected_config];
            lbl.backgroundColor = selected ? TT_Accent() : TT_RowAlt();
            lbl.layer.cornerRadius = 4;
            lbl.layer.masksToBounds = YES;
            lbl.userInteractionEnabled = YES;
            lbl.tag = 1;  // selectable config row (empty-state label keeps tag 0)
            [_configList addSubview:lbl];
            y += 32;
        }
    }
    _configList.contentSize = CGSizeMake(_configList.bounds.size.width, y + 6);
}

- (void)selectConfigLabel:(UILabel *)lbl {
    esp_selected_config = [lbl.text stringByTrimmingCharactersInSet:
        [NSCharacterSet whitespaceCharacterSet]];
    [self refreshConfigList];
}

- (void)createConfigFlow {
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    f.dateFormat = @"yyyyMMdd_HHmmss";
    NSString *name = [NSString stringWithFormat:@"@x1work_%@", [f stringFromDate:[NSDate date]]];
    cfg_create(name);
    esp_selected_config = name;
    [self refreshConfigList];
}

- (void)deleteConfigFlow {
    if (esp_selected_config.length == 0) return;
    cfg_delete(esp_selected_config);
    esp_selected_config = nil;
    [self refreshConfigList];
}

- (void)loadConfigFlow {
    if (esp_selected_config.length == 0) return;
    cfg_load(esp_selected_config);
    [self resyncControlsFromExterns];
}

// Called after cfg_load so the switches/sliders reflect the new values in
// the externs. Every control that mirrors a persisted feature is here.
- (void)resyncControlsFromExterns {
    [_swBox setOn:esp_box_enabled animated:NO];
    [_swBoxOutline setOn:esp_box_outline animated:NO];
    [_swBoxFill setOn:esp_box_fill animated:NO];
    [_swBoxCorner setOn:esp_box_corner animated:NO];
    [_swBox3D setOn:esp_box_3d animated:NO];
    [_swLine setOn:esp_line_enabled animated:NO];
    [_swLineOutline setOn:esp_line_outline animated:NO];
    [_swTeam setOn:esp_team_check animated:NO];
    [_swName setOn:esp_name_enabled animated:NO];
    [_swNameOutline setOn:esp_name_outline animated:NO];
    [_swHealth setOn:esp_health_enabled animated:NO];
    [_swHealthBar setOn:esp_health_bar_enabled animated:NO];
    [_swHealthBarOutline setOn:esp_health_bar_outline animated:NO];
    [_swWeapon setOn:esp_weapon_enabled animated:NO];
    [_swWeaponIcon setOn:esp_weapon_icon_enabled animated:NO];
    [_swPlatform setOn:esp_platform_enabled animated:NO];
    [_swAvatar setOn:esp_avatar_enabled animated:NO];
    [_swSkeleton setOn:esp_skeleton_enabled animated:NO];
    [_swSkeletonOccluded setOn:esp_skeleton_occluded animated:NO];
    [_swViewmodel setOn:viewmodel_enabled animated:NO];

    [_swInvisible setOn:esp_invisible animated:NO];
    [_swAddScore  setOn:esp_addscore  animated:NO];
    [_swInfAmmo   setOn:esp_inf_ammo  animated:NO];
    [_swNoSpread  setOn:esp_no_spread animated:NO];
    [_swAirJump   setOn:esp_air_jump  animated:NO];
    [_swFastKnife setOn:esp_fast_knife animated:NO];
    [_swWallshot  setOn:esp_wallshot  animated:NO];
    [_swFireRate  setOn:esp_fire_rate animated:NO];
    [_swRCS       setOn:esp_rcs_enabled animated:NO];
    [_swAlwaysHead setOn:player_always_head animated:NO];
    [_swFreezeLocal setOn:player_freeze_local animated:NO];
    [_swFreezeEnemies setOn:player_freeze_enemies animated:NO];
    [_swAntiFlash setOn:player_anti_flash animated:NO];
    [_swAntiMolotov setOn:player_anti_molotov animated:NO];

    [_swAimbot     setOn:aimbot_enabled        animated:NO];
    [_swTriggerbot setOn:aimbot_triggerbot     animated:NO];
    [_swAimFov     setOn:aimbot_fov_visible    animated:NO];
    [_swVisCheck   setOn:aimbot_visible_check  animated:NO];
    [_swFireCheck  setOn:aimbot_shooting_check animated:NO];
    [_swKnifeBot   setOn:aimbot_knife_bot      animated:NO];
    [_swAimTeam    setOn:aimbot_team_check     animated:NO];

    [_swOverlay    setOn:esp_screenshot_safe   animated:NO];
    if (self.superview) [self.superview hideViewFromCapture:esp_screenshot_safe];
    else                [self hideViewFromCapture:esp_screenshot_safe];

    _sldSmooth.value = aimbot_smooth;                 _lblSmooth.text = [NSString stringWithFormat:@"%.1f", aimbot_smooth];
    _sldFov.value = aimbot_fov;                       _lblFov.text = [NSString stringWithFormat:@"%.0f", aimbot_fov];
    _sldTriggerDelay.value = aimbot_trigger_delay;    _lblTriggerDelay.text = [NSString stringWithFormat:@"%.2f", aimbot_trigger_delay];
    _sldRCSH.value = esp_rcs_h;                       _lblRCSH.text = [NSString stringWithFormat:@"%.1f", esp_rcs_h];
    _sldRCSV.value = esp_rcs_v;                       _lblRCSV.text = [NSString stringWithFormat:@"%.1f", esp_rcs_v];
    _sldVmX.value = viewmodel_x;                      _lblVmX.text = [NSString stringWithFormat:@"%.1f", viewmodel_x];
    _sldVmY.value = viewmodel_y;                      _lblVmY.text = [NSString stringWithFormat:@"%.1f", viewmodel_y];
    _sldVmZ.value = viewmodel_z;                      _lblVmZ.text = [NSString stringWithFormat:@"%.1f", viewmodel_z];

    if (_boneSelector) _boneSelector.selectedSegmentIndex = aimbot_bone_index;
}

#pragma mark - Skin manager

- (void)refreshSkinList {
    if (!_skinList) return;
    // Only pay the process-attach cost when the tab is actually visible.
    if (_currentTab != TT_TAB_SKINS) return;

    static pid_t   c_pid  = 0;
    static task_t  c_task = 0;
    static mach_vm_address_t c_base = 0;

    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) {
        c_pid = 0; c_task = 0; c_base = 0;
        [self renderEmptySkinListWithMessage:@(OBF("Game is not running"))];
        return;
    }
    if (pid != c_pid || !c_task || !c_base) {
        c_task = get_task_by_pid(pid);
        if (c_task) c_base = get_image_base_address(c_task, "UnityFramework");
        c_pid = pid;
    }
    if (!c_task || !c_base) {
        [self renderEmptySkinListWithMessage:@(OBF("Attach failed"))];
        return;
    }

    // Same walk as the previous impl: InventoryManager typeInfo -> parent ->
    // staticFields -> instance. The 148490880 offset and the two staticFields
    // slots (0xB8 primary, 0xB0 fallback) are what the existing skin logic
    // uses; kept untouched.
    uintptr_t typeInfo = Read<uintptr_t>(c_base + 148490880, c_task);
    if (!typeInfo) { [self renderEmptySkinListWithMessage:@(OBF("Inventory unavailable"))]; return; }
    uintptr_t parentTypeInfo = Read<uintptr_t>(typeInfo + 0x58, c_task);
    if (!parentTypeInfo) { [self renderEmptySkinListWithMessage:@(OBF("Inventory unavailable"))]; return; }
    uintptr_t staticFields = Read<uintptr_t>(parentTypeInfo + 0xB8, c_task);
    if (!staticFields || staticFields < 0x1000000)
        staticFields = Read<uintptr_t>(parentTypeInfo + 0xB0, c_task);
    if (!staticFields) { [self renderEmptySkinListWithMessage:@(OBF("Inventory unavailable"))]; return; }
    uintptr_t inventoryManager = Read<uintptr_t>(staticFields, c_task);
    if (!inventoryManager) { [self renderEmptySkinListWithMessage:@(OBF("Inventory unavailable"))]; return; }

    // Rendering: two sections, YOUR INVENTORY and REPLACEMENT. Empty owned
    // vector is the loud case the user is most likely to hit until skin
    // scraping is wired back; render a hint instead of a bare header.
    for (UIView *v in [_skinList.subviews copy]) [v removeFromSuperview];
    CGFloat y = 6;
    CGFloat rowW = _skinList.bounds.size.width - 12;

    [self appendSkinHeader:@(OBF("YOUR INVENTORY")) atY:&y width:rowW];
    if (_ownedSkinsInfo.empty()) {
        [self appendSkinHint:@(OBF("Inventory empty")) atY:&y width:rowW];
    } else {
        for (int i = 0; i < (int)_ownedSkinsInfo.size(); i++) {
            [self appendSkinRow:[NSString stringWithFormat:@"Skin #%d", _ownedSkinsInfo[i].first]
                        selected:(i == _selectedOwnedIdx)
                             tag:(1000 + i)
                             atY:&y
                           width:rowW];
        }
    }
    y += 6;
    [self appendSkinHeader:@(OBF("REPLACEMENT")) atY:&y width:rowW];
    if (_allSkinsList.empty()) {
        [self appendSkinHint:@(OBF("No replacement skins loaded")) atY:&y width:rowW];
    } else {
        for (int i = 0; i < (int)_allSkinsList.size(); i++) {
            NSString *nm = [NSString stringWithUTF8String:_allSkinsList[i].second.c_str()];
            [self appendSkinRow:nm
                        selected:(i == _selectedReplaceIdx)
                             tag:(2000 + i)
                             atY:&y
                           width:rowW];
        }
    }

    _skinList.contentSize = CGSizeMake(_skinList.bounds.size.width, y + 6);
}

- (void)renderEmptySkinListWithMessage:(NSString *)msg {
    for (UIView *v in [_skinList.subviews copy]) [v removeFromSuperview];
    UILabel *l = [[UILabel alloc] initWithFrame:
        CGRectMake(6, 8, _skinList.bounds.size.width - 12, 26)];
    l.text = msg;
    l.textColor = TT_TextSecondary();
    l.font = [UIFont italicSystemFontOfSize:12];
    [_skinList addSubview:l];
    _skinList.contentSize = CGSizeMake(_skinList.bounds.size.width, 40);
}

- (void)appendSkinHeader:(NSString *)title atY:(CGFloat *)y width:(CGFloat)w {
    UILabel *h = [[UILabel alloc] initWithFrame:CGRectMake(6, *y, w, 20)];
    h.text = title;
    h.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    h.textColor = TT_TextSecondary();
    [_skinList addSubview:h];
    *y += 22;
}

- (void)appendSkinHint:(NSString *)msg atY:(CGFloat *)y width:(CGFloat)w {
    UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(6, *y, w, 24)];
    l.text = msg;
    l.font = [UIFont italicSystemFontOfSize:12];
    l.textColor = TT_TextSecondary();
    [_skinList addSubview:l];
    *y += 28;
}

- (void)appendSkinRow:(NSString *)title selected:(BOOL)selected tag:(NSInteger)tag
                  atY:(CGFloat *)y width:(CGFloat)w
{
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(6, *y, w, 28)];
    lbl.text = [NSString stringWithFormat:@"  %@", title];
    lbl.font = [UIFont systemFontOfSize:13];
    lbl.textColor = TT_TextPrimary();
    lbl.backgroundColor = selected ? TT_Accent() : TT_RowAlt();
    lbl.layer.cornerRadius = 4;
    lbl.layer.masksToBounds = YES;
    lbl.userInteractionEnabled = YES;
    lbl.tag = tag;
    [_skinList addSubview:lbl];
    *y += 32;
}

- (void)skinRowTappedWithTag:(NSInteger)tag {
    if (tag >= 2000)      _selectedReplaceIdx = (int)tag - 2000;
    else if (tag >= 1000) _selectedOwnedIdx   = (int)tag - 1000;
    else return;
    [self refreshSkinList];
    [self tryApplySkinPair];
}

- (void)tryApplySkinPair {
    if (_selectedOwnedIdx < 0 || _selectedOwnedIdx >= (int)_ownedSkinsInfo.size()) return;
    if (_selectedReplaceIdx < 0 || _selectedReplaceIdx >= (int)_allSkinsList.size()) return;
    uintptr_t skinPtr = _ownedSkinsInfo[_selectedOwnedIdx].second;
    int newId = _allSkinsList[_selectedReplaceIdx].first;
    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) return;
    task_t task = get_task_by_pid(pid);
    if (!task) return;
    Write<int>(skinPtr + 0x10, newId, task);
}

#pragma mark - Touch routing

// The menu claims every touch inside
// its bounds and dispatches it by hand. UISegmentedControl / UISwitch /
// UIScrollView never see HUD touches directly -- their own tracking and
// gesture recognizers are what broke tab switching and crashed on taps into
// empty scroll area.
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (self.hidden || self.alpha < 0.01 || !self.userInteractionEnabled) return nil;
    if (!CGRectContainsPoint(self.bounds, point)) return nil;

    // MenuView owns the touch stream while visible.
    return self;
}

- (id)ancestorOf:(UIView *)view kindOf:(Class)cls {
    for (UIView *v = view; v && v != self; v = v.superview) {
        if ([v isKindOfClass:cls]) return v;
    }
    return nil;
}

// A tap anywhere on a toggle row flips its switch.
- (UISwitch *)switchForView:(UIView *)view {
    for (UIView *v = view; v && v != self; v = v.superview) {
        if ([v isKindOfClass:[UISwitch class]]) return (UISwitch *)v;
        if ([v isKindOfClass:[UIScrollView class]]) break;
        for (UIView *sub in v.subviews) {
            if ([sub isKindOfClass:[UISwitch class]]) return (UISwitch *)sub;
        }
    }
    return nil;
}

- (void)applySlider:(UISlider *)slider atMenuPoint:(CGPoint)point {
    CGPoint p = [self convertPoint:point toView:slider];
    CGRect track = [slider trackRectForBounds:slider.bounds];
    if (track.size.width < 1.0) return;
    CGFloat t = (p.x - track.origin.x) / track.size.width;
    t = MAX(0.0, MIN(1.0, t));
    slider.value = slider.minimumValue + (slider.maximumValue - slider.minimumValue) * t;
    [slider sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)selectSegmentOf:(UISegmentedControl *)seg atMenuPoint:(CGPoint)point {
    if (seg.numberOfSegments == 0) return;
    CGPoint p = [self convertPoint:point toView:seg];
    if (!CGRectContainsPoint(seg.bounds, p)) return;
    NSInteger idx = (NSInteger)(p.x / (seg.bounds.size.width / seg.numberOfSegments));
    idx = MAX(0, MIN(seg.numberOfSegments - 1, idx));
    if (idx == seg.selectedSegmentIndex) return;
    seg.selectedSegmentIndex = idx;
    [seg sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)resetTouchState {
    _activeTouchView = nil;
    _activeScrollView = nil;
    _activeSlider = nil;
    _scrolling = NO;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint point = [touches.anyObject locationInView:self];
    [self resetTouchState];
    _touchStartPoint = point;
    _activeTouchView = [super hitTest:point withEvent:event];

    UISlider *slider = [self ancestorOf:_activeTouchView kindOf:[UISlider class]];
    if (slider) {
        _activeSlider = slider;
        [self applySlider:slider atMenuPoint:point];
        return;
    }

    _activeScrollView = [self ancestorOf:_activeTouchView kindOf:[UIScrollView class]];
    if (_activeScrollView) _scrollStartOffset = _activeScrollView.contentOffset;
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint point = [touches.anyObject locationInView:self];

    if (_activeSlider) {
        [self applySlider:_activeSlider atMenuPoint:point];
        return;
    }
    if (!_activeScrollView) return;

    CGFloat totalDY = point.y - _touchStartPoint.y;
    if (!_scrolling && fabs(totalDY) > 6.0) _scrolling = YES;
    if (!_scrolling) return;

    CGPoint offset = _scrollStartOffset;
    offset.y -= totalDY;
    CGFloat maxY = MAX(0.0, _activeScrollView.contentSize.height - _activeScrollView.bounds.size.height);
    offset.y = MAX(0.0, MIN(maxY, offset.y));
    _activeScrollView.contentOffset = offset;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint point = [touches.anyObject locationInView:self];
    UIView *hit = _activeTouchView;
    BOOL wasScrollOrSlide = _scrolling || _activeSlider != nil;
    [self resetTouchState];
    if (wasScrollOrSlide) return;

    if (!hit) return;

    UISegmentedControl *seg = [self ancestorOf:hit kindOf:[UISegmentedControl class]];
    if (seg) { [self selectSegmentOf:seg atMenuPoint:point]; return; }

    UIButton *button = [self ancestorOf:hit kindOf:[UIButton class]];
    if (button) { [button sendActionsForControlEvents:UIControlEventTouchUpInside]; return; }

    UISwitch *sw = [self switchForView:hit];
    if (sw) {
        [sw setOn:!sw.on animated:YES];
        [sw sendActionsForControlEvents:UIControlEventValueChanged];
        return;
    }

    if ([hit isKindOfClass:[UILabel class]]) {
        if (hit.superview == _configList && hit.tag == 1) {
            [self selectConfigLabel:(UILabel *)hit];
        } else if (hit.superview == _skinList) {
            [self skinRowTappedWithTag:hit.tag];
        }
    }
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self resetTouchState];
}

#pragma mark - Position

- (NSInteger)readMenuPosition {
    NSString *str = [NSString stringWithContentsOfFile:kMenuPosPath
                                              encoding:NSUTF8StringEncoding error:nil];
    return str ? [str integerValue] : 0;
}

- (void)applyMenuPosition {
    if (!self.superview) return;
    NSInteger pos = [self readMenuPosition];
    _lastAppliedPosition = pos;

    CGSize size = _expandedSize;
    CGRect sb   = self.superview.bounds;
    CGFloat pad = 20.0;

    CGFloat x, y;
    switch (pos) {
        case 0: x = pad; y = pad; break;
        case 1: x = sb.size.width - size.width - pad; y = pad; break;
        case 2: x = pad; y = sb.size.height - size.height - pad; break;
        case 3: x = sb.size.width  - size.width  - pad;
                y = sb.size.height - size.height - pad; break;
        default: x = (sb.size.width - size.width)  / 2.0;
                 y = (sb.size.height - size.height) / 2.0; break;
    }
    self.frame = CGRectMake(x, y, size.width, size.height);
}

- (void)pollMenuPosition {
    NSInteger pos = [self readMenuPosition];
    if (pos != _lastAppliedPosition) [self applyMenuPosition];
}

- (void)didMoveToSuperview {
    [super didMoveToSuperview];
    [self applyMenuPosition];
}

@end
