#import "esp.h"
#include "../unity_api/so2_v100_runtime.h"
#import "tt.h"
#import <UIKit/UIGestureRecognizerSubclass.h>
#import <AVFoundation/AVFoundation.h>
#import <objc/runtime.h>
#import <sys/sysctl.h>
#include "obfusheader.h"
#import "../../sources/UIView+SecureView.h"
#include "../Player/alwh.h"
#include "../Player/freezep.h"
#include "../Player/molotov_flash.h"
#include "../Player/aim360.h"
#include <atomic>
#include <cmath>
// Rifles
#import "assets/rifles/akr.h"
#import "assets/rifles/akr12.h"
#import "assets/rifles/famas.h"
#import "assets/rifles/fnfal.h"
#import "assets/rifles/m16.h"
#import "assets/rifles/m4.h"
#import "assets/rifles/val.h"
// Pistols
#import "assets/pistols/berettas.h"
#import "assets/pistols/desert_eagle.h"
#import "assets/pistols/five_seven.h"
#import "assets/pistols/g22.h"
#import "assets/pistols/p350.h"
#import "assets/pistols/tec9.h"
#import "assets/pistols/usp.h"
// SMGs
#import "assets/smgs/mac10.h"
#import "assets/smgs/mp5.h"
#import "assets/smgs/mp7.h"
#import "assets/smgs/p90.h"
#import "assets/smgs/ump45.h"
#import "assets/smgs/uzi.h"
// Heavy
#import "assets/heavy/fabm.h"
#import "assets/heavy/m60.h"
#import "assets/heavy/sm1014.h"
#import "assets/heavy/spas.h"
// Snipers
#import "assets/snipers/awm.h"
#import "assets/snipers/m110.h"
#import "assets/snipers/m40.h"
#import "assets/snipers/mallard.h"
// Knives
#import "assets/knives/butterfly.h"
#import "assets/knives/dual_daggers.h"
#import "assets/knives/fang.h"
#import "assets/knives/flipknife.h"
#import "assets/knives/jkommando.h"
#import "assets/knives/kabar.h"
#import "assets/knives/karambit.h"
#import "assets/knives/kukri.h"
#import "assets/knives/kunai.h"
#import "assets/knives/m9bayonet.h"
#import "assets/knives/mantis.h"
#import "assets/knives/scorpion.h"
#import "assets/knives/stiletto.h"
#import "assets/knives/sting.h"
#import "assets/knives/tanto.h"
// Grenades
#import "assets/grenades/flash.h"
#import "assets/grenades/he.h"
#import "assets/grenades/molotov.h"
#import "assets/grenades/smoke.h"
#import "assets/grenades/thermite.h"
// Other
#import "assets/other/bomb.h"

volatile bool esp_box_enabled = true;
volatile bool esp_box_outline = false;
volatile bool esp_box_fill = false;
volatile bool esp_box_corner = false;
volatile bool esp_box_3d = false;
volatile bool esp_line_enabled = false;
volatile bool esp_line_outline = false;
volatile bool esp_invisible = false;
volatile bool esp_addscore = false;
volatile bool esp_inf_ammo = false;
volatile bool esp_no_spread = false;
volatile bool esp_air_jump = false;
volatile bool esp_fast_knife = false;
volatile bool esp_wallshot = false;
volatile bool esp_fire_rate = false;
volatile bool esp_team_check = true;
volatile bool esp_screenshot_safe = false;

volatile bool aimbot_enabled        = false;
volatile bool aimbot_visible_check  = false;
volatile bool aimbot_shooting_check = false;
volatile bool aimbot_knife_bot      = false;
volatile float aimbot_smooth        = 5.0f;
volatile float aimbot_trigger_delay = 0.1f;
volatile int   aimbot_bone_index    = 0;   

volatile bool  esp_rcs_enabled   = false;
volatile float esp_rcs_h         = 0.0f;
volatile float esp_rcs_v         = 0.0f;

volatile bool aimbot_triggerbot   = false;
volatile bool aimbot_fov_visible  = true;
volatile float aimbot_fov         = 120.0f;
volatile bool aimbot_team_check   = true;
volatile bool esp_name_enabled = false;
volatile bool esp_name_outline = false;
volatile bool esp_health_enabled = false;
volatile bool esp_health_bar_enabled = false;
volatile bool esp_health_bar_outline = false;
volatile bool esp_weapon_enabled     = false;
volatile bool esp_weapon_icon_enabled = false;
volatile bool esp_platform_enabled = false;
volatile bool esp_avatar_enabled   = false;

// Skeleton ESP. `esp_skeleton_occluded` is the occlusion bypass: keeps
// occluded players' bones updating and paints them in the occluded colour.
volatile bool esp_skeleton_enabled = false;
volatile bool esp_skeleton_occluded = false;

volatile bool  viewmodel_enabled  = false;
volatile float viewmodel_x        = 0.0f;
volatile float viewmodel_y        = 0.0f;
volatile float viewmodel_z        = 0.0f;

volatile bool esp_auto_load = false;
NSString *esp_selected_config = nil;

// Additional Player functions supplied for this build.
volatile bool player_always_head    = false;
volatile bool player_freeze_local   = false;
volatile bool player_freeze_enemies = false;
volatile bool player_anti_flash     = false;
volatile bool player_anti_molotov   = false;

@interface UIWindow (Private)
- (void)_setSecure:(BOOL)secure;
- (unsigned int)_contextId;
@end

@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (BOOL)openApplicationWithBundleID:(NSString *)bundleID;
@end

@interface SBSAccessibilityWindowHostingController : NSObject
- (void)registerWindowWithContextID:(unsigned int)contextID atLevel:(double)level;
@end

struct ESPBoxData {
    CGRect rect;
};

// 19 bone slots inside BipedMap.
// 0 head, 1 neck, 2-3 spine, 4-6 / 7-11 arms, 12 pelvis, 13-15 / 16-18 legs.
static const int kBoneCount = 19;
static const int bone_offsets[kBoneCount] = {
    0x20, 0x28, 0x38, 0x40,
    0x50, 0x58, 0x60, 0x48,
    0x68, 0x70, 0x78, 0x80,
    0x88,
    0x90, 0x98, 0xA0,
    0xB0, 0xB8, 0xC0
};

struct BoneEdge { int a, b; };
static const BoneEdge bone_connections[] = {
    {0, 1},
    {1, 3}, {3, 2}, {2, 12},
    {1, 8}, {8, 9}, {9, 10}, {10, 11},
    {1, 7}, {7, 4}, {4, 5}, {5, 6},
    {12, 13}, {13, 14}, {14, 15},
    {12, 16}, {16, 17}, {17, 18}
};

// A bone farther than this from the player's feet is a bad read, not a pose.
static const float kMaxBoneDistFromRoot = 2.5f;
static const int kBoneEdgeCount = sizeof(bone_connections) / sizeof(bone_connections[0]);

// Forward declaration: definition below the @implementation block, but the
// skeleton renderer inside update_data needs it up front.

@interface ESP_View ()
@property (nonatomic, strong) CADisplayLink     *displayLinkData;
@property (nonatomic, strong) UILabel           *playerCountLabel;
@property (nonatomic, strong) UILabel           *noPlayersLabel;
@property (nonatomic, strong) AVPlayer          *backgroundPlayer;
@property (nonatomic, assign) BOOL              hasAttemptedLaunch;
@property (nonatomic, strong) CAShapeLayer      *espBoxLayer;
@property (nonatomic, strong) CAShapeLayer      *espBoxFillLayer;
@property (nonatomic, strong) NSMutableArray<UILabel *> *nameLabelPool;
@property (nonatomic, strong) NSMutableArray<UILabel *> *healthLabelPool;
@property (nonatomic, strong) NSMutableArray<UILabel *> *weaponLabelPool;
@property (nonatomic, strong) NSMutableArray<UIImageView *> *weaponIconPool;
@property (nonatomic, strong) NSMutableArray<UILabel *> *platformLabelPool;
@property (nonatomic, strong) NSMutableArray<UIImageView *> *avatarPool;
@property (nonatomic, strong) CAShapeLayer      *espLineLayer;
@property (nonatomic, strong) CAShapeLayer      *espBoxOutlineLayer;
@property (nonatomic, strong) CAShapeLayer      *espHealthBarLayer;
@property (nonatomic, strong) CAShapeLayer      *espHealthBarOutlineLayer;
@property (nonatomic, strong) CAShapeLayer      *espLineOutlineLayer;
@property (nonatomic, strong) CAShapeLayer      *espSkeletonLayer;
@property (nonatomic, strong) CAShapeLayer      *espSkeletonOccludedLayer;
@property (nonatomic, strong) UILabel           *watermarkLabel;
@property (nonatomic, strong) CAShapeLayer      *fovCircleLayer;
@property (nonatomic, strong) CAShapeLayer      *fovCircleOutlineLayer;
@property (nonatomic, assign) uint64_t          aimbotCurrentTarget;
@property (nonatomic, assign) double            aimbotLastWriteTime;
@property (nonatomic, assign) BOOL              triggerbotShooting;
@property (nonatomic, assign) double            triggerbotLastShotTime;
@property (nonatomic, assign) BOOL              isESPCountEnabled;
@end

static SO2V100::Runtime gSO2V100Runtime;
static std::vector<SO2V100::PlayerSnapshot> gSO2V100Players;

@implementation ESP_View

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.backgroundColor        = [UIColor clearColor];
    self.hasAttemptedLaunch     = NO;
    self.isESPCountEnabled      = NO;
    self.userInteractionEnabled = YES;

    self.espBoxFillLayer = [CAShapeLayer layer];
    self.espBoxFillLayer.fillColor = [UIColor colorWithWhite:1 alpha:0.3].CGColor;
    self.espBoxFillLayer.strokeColor = [UIColor clearColor].CGColor;
    [self.layer addSublayer:self.espBoxFillLayer];

    self.espBoxOutlineLayer = [CAShapeLayer layer];
    self.espBoxOutlineLayer.strokeColor = [UIColor blackColor].CGColor;
    self.espBoxOutlineLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espBoxOutlineLayer.lineWidth   = 3.0;
    [self.layer addSublayer:self.espBoxOutlineLayer];

    self.espBoxLayer = [CAShapeLayer layer];
    self.espBoxLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.espBoxLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espBoxLayer.lineWidth   = 1.5;
    [self.layer addSublayer:self.espBoxLayer];

    self.espHealthBarOutlineLayer = [CAShapeLayer layer];
    self.espHealthBarOutlineLayer.strokeColor = [UIColor blackColor].CGColor;
    self.espHealthBarOutlineLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espHealthBarOutlineLayer.lineWidth   = 3.0;
    [self.layer addSublayer:self.espHealthBarOutlineLayer];

    self.espHealthBarLayer = [CAShapeLayer layer];
    self.espHealthBarLayer.strokeColor = [UIColor colorWithRed:0.0 green:1.0 blue:0.0 alpha:0.8].CGColor;
    self.espHealthBarLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espHealthBarLayer.lineWidth   = 2.0;
    [self.layer addSublayer:self.espHealthBarLayer];

    self.espLineOutlineLayer = [CAShapeLayer layer];
    self.espLineOutlineLayer.strokeColor = [UIColor blackColor].CGColor;
    self.espLineOutlineLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espLineOutlineLayer.lineWidth   = 3.0;
    [self.layer addSublayer:self.espLineOutlineLayer];

    self.espLineLayer = [CAShapeLayer layer];
    self.espLineLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.espLineLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espLineLayer.lineWidth   = 1.0;
    [self.layer addSublayer:self.espLineLayer];

    // Two skeleton layers, painted from the same 19-point bone table but split
    // by the per-player occlusion check. The occluded layer sits underneath so
    // the visible one overpaints when a bone crosses the boundary within a
    // single frame.
    self.espSkeletonOccludedLayer = [CAShapeLayer layer];
    self.espSkeletonOccludedLayer.strokeColor = [UIColor colorWithRed:1.0 green:0.85 blue:0.0 alpha:1.0].CGColor;
    self.espSkeletonOccludedLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espSkeletonOccludedLayer.lineWidth   = 1.0;
    self.espSkeletonOccludedLayer.lineCap     = kCALineCapRound;
    self.espSkeletonOccludedLayer.lineJoin    = kCALineJoinRound;
    [self.layer addSublayer:self.espSkeletonOccludedLayer];

    self.espSkeletonLayer = [CAShapeLayer layer];
    self.espSkeletonLayer.strokeColor = [UIColor colorWithRed:0.1 green:1.0 blue:0.25 alpha:1.0].CGColor;
    self.espSkeletonLayer.fillColor   = [UIColor clearColor].CGColor;
    self.espSkeletonLayer.lineWidth   = 1.2;
    self.espSkeletonLayer.lineCap     = kCALineCapRound;
    self.espSkeletonLayer.lineJoin    = kCALineJoinRound;
    [self.layer addSublayer:self.espSkeletonLayer];

    self.fovCircleOutlineLayer = [CAShapeLayer layer];
    self.fovCircleOutlineLayer.fillColor   = [UIColor clearColor].CGColor;
    self.fovCircleOutlineLayer.strokeColor = [UIColor colorWithWhite:0 alpha:0.6].CGColor;
    self.fovCircleOutlineLayer.lineWidth   = 3.0;
    self.fovCircleOutlineLayer.hidden      = YES;
    [self.layer addSublayer:self.fovCircleOutlineLayer];

    self.fovCircleLayer = [CAShapeLayer layer];
    self.fovCircleLayer.fillColor   = [UIColor clearColor].CGColor;
    self.fovCircleLayer.strokeColor = [UIColor whiteColor].CGColor;
    self.fovCircleLayer.lineWidth   = 1.5;
    self.fovCircleLayer.hidden      = YES;
    [self.layer addSublayer:self.fovCircleLayer];

    UILabel *wm = [[UILabel alloc] init];
    wm.text = @(OBF(" "));
    wm.textColor = [UIColor whiteColor];
    wm.font = [UIFont boldSystemFontOfSize:16.0f];
    wm.userInteractionEnabled = NO;
    [self addSubview:wm];
    self.watermarkLabel = wm;

    UILabel *playerCountLabel = [UILabel new];
    playerCountLabel.hidden = YES;
    self.playerCountLabel = playerCountLabel;

    UILabel *noPlayersLabel = [UILabel new];
    noPlayersLabel.hidden = YES;
    self.noPlayersLabel = noPlayersLabel;

    self.nameLabelPool = [NSMutableArray new];
    self.healthLabelPool = [NSMutableArray new];
    self.weaponLabelPool = [NSMutableArray new];
    self.weaponIconPool = [NSMutableArray new];
    self.platformLabelPool = [NSMutableArray new];
    self.avatarPool = [NSMutableArray new];
    self.aimbotCurrentTarget = 0;
    self.aimbotLastWriteTime = 0;
    self.triggerbotShooting = NO;
    self.triggerbotLastShotTime = 0;

    self.menuView = [[MenuView alloc] initWithFrame:CGRectMake(0, 0, 520, 320)];
    self.menuView.center = CGPointMake(frame.size.width / 2, frame.size.height / 2);
    self.menuView.hidden = YES;
    [self addSubview:self.menuView];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(toggleMenuVisibility)
                                                 name:@"LegendaClientMenuToggle"
                                               object:nil];

    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(clearAllBoxes)
               name:@"ESPClearBoxes"
             object:nil];

    [self startBackgroundKeeper];

    self.displayLinkData = [CADisplayLink displayLinkWithTarget:self selector:@selector(update_data)];
    self.displayLinkData.preferredFramesPerSecond = 120;
    [self.displayLinkData addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    [self showViewForCapture];

    return self;
}


- (void)toggleMenuVisibility {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *menu = self.menuView;
        if (!menu) return;

        // Animate from/to the center: quick, subtle zoom with a simultaneous fade.
        if (menu.hidden) {
            menu.hidden = NO;
            menu.userInteractionEnabled = YES;
            menu.alpha = 0.0;
            menu.transform = CGAffineTransformMakeScale(0.72, 0.72);
            [UIView animateWithDuration:0.22
                                  delay:0.0
                                options:UIViewAnimationOptionCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                                 menu.alpha = 1.0;
                                 menu.transform = CGAffineTransformIdentity;
                             }
                             completion:nil];
        } else {
            menu.userInteractionEnabled = NO;
            [UIView animateWithDuration:0.16
                                  delay:0.0
                                options:UIViewAnimationOptionCurveEaseIn | UIViewAnimationOptionBeginFromCurrentState
                             animations:^{
                                 menu.alpha = 0.0;
                                 menu.transform = CGAffineTransformMakeScale(0.72, 0.72);
                             }
                             completion:^(BOOL finished) {
                                 menu.hidden = YES;
                                 menu.alpha = 1.0;
                                 menu.transform = CGAffineTransformIdentity;
                             }];
        }
    });
}

- (void)dealloc {
    [self.displayLinkData invalidate];
    self.displayLinkData = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)clearAllBoxes {
    self.espBoxLayer.path        = nil;
    self.espBoxFillLayer.path    = nil;
    self.espLineLayer.path       = nil;
    self.espBoxOutlineLayer.path = nil;
    self.espLineOutlineLayer.path = nil;
    self.espHealthBarLayer.path  = nil;
    self.espHealthBarOutlineLayer.path = nil;
    self.espSkeletonLayer.path   = nil;
    self.espSkeletonOccludedLayer.path = nil;
    self.fovCircleLayer.hidden        = YES;
    self.fovCircleOutlineLayer.hidden = YES;
    for (UILabel *lbl in self.nameLabelPool) lbl.hidden = YES;
    for (UILabel *lbl in self.healthLabelPool) lbl.hidden = YES;
    for (UILabel *lbl in self.weaponLabelPool) lbl.hidden = YES;
    for (UIImageView *img in self.weaponIconPool) img.hidden = YES;
    for (UILabel *lbl in self.platformLabelPool) lbl.hidden = YES;
    for (UIImageView *img in self.avatarPool) img.hidden = YES;
}

- (void)update_data {
    const bool anyVisualFeature = esp_box_enabled || esp_box_3d || esp_box_corner || esp_box_fill ||
        esp_line_enabled || esp_name_enabled || esp_health_enabled || esp_health_bar_enabled ||
        esp_weapon_enabled || esp_weapon_icon_enabled || esp_platform_enabled || esp_avatar_enabled ||
        esp_skeleton_enabled;
    const bool anyGameplayFeature = aimbot_enabled || aimbot_triggerbot || viewmodel_enabled ||
        esp_invisible || esp_addscore || esp_inf_ammo || esp_no_spread || esp_air_jump ||
        esp_fast_knife || esp_wallshot || esp_fire_rate || esp_rcs_enabled ||
        player_always_head || player_freeze_local || player_freeze_enemies ||
        player_anti_flash || player_anti_molotov;
    if (!anyVisualFeature && !anyGameplayFeature) {
        [self clearAllBoxes];
        self.watermarkLabel.text = @(OBF(" "));
        [self.watermarkLabel sizeToFit];
        return;
    }

    static pid_t cached_so2_pid = 0;
    static task_t cached_so2_task = 0;
    static mach_vm_address_t cached_unity_base = 0;

    pid_t so2_pid = get_pid_by_name("Standoff2");

    if (so2_pid <= 0) {
        cached_so2_pid = 0;
        cached_so2_task = 0;
        cached_unity_base = 0;

        [self clearAllBoxes];

        self.playerCountLabel.text      = @(OBF("LAUNCHING..."));
        self.playerCountLabel.textColor = [UIColor redColor];
        self.noPlayersLabel.hidden      = YES;
        self.watermarkLabel.text = @(OBF(" "));
        [self.watermarkLabel sizeToFit];

        if (!self.hasAttemptedLaunch) {
            [self launchGame];
            self.hasAttemptedLaunch = YES;
        }
        return;
    }

    if (so2_pid != cached_so2_pid || !cached_so2_task || !cached_unity_base) {
        cached_so2_task = get_task_by_pid(so2_pid);
        if (cached_so2_task) {
            cached_unity_base = get_image_base_address(cached_so2_task, "UnityFramework");
        }
        cached_so2_pid = so2_pid;
    }

    task_t so2_task = cached_so2_task;
    if (!so2_task) goto CLEAR_BOXES;

    {
        mach_vm_address_t unity_base = cached_unity_base;
        if (!unity_base) goto CLEAR_BOXES;

        // Global grenade-effect modifiers supplied for the Player tab.
        // Grenade dictionary layout from the previous build is not valid for 1.0.0.
        // No legacy grenade writes are executed here.

        // Standoff 2 1.0.0: resolve the world/player graph through the
        // validated ARM64 TypeInfo slots and FieldInfo offsets. The old
        // The legacy manager chain is intentionally not used.
        if (!gSO2V100Runtime.ready() ||
            gSO2V100Runtime.unityBase() != unity_base) {
            gSO2V100Runtime.initialize(so2_task, unity_base);
        }
        if (!gSO2V100Runtime.ready() ||
            !gSO2V100Runtime.collectPlayers(gSO2V100Players)) {
            goto CLEAR_BOXES;
        }

        const auto &v100Players = gSO2V100Players;
        mach_vm_address_t localPlayer =
            (mach_vm_address_t)gSO2V100Runtime.localPlayer();
        int playersCount = (int)v100Players.size();

        // 1.0.0 validation status: input/command, recoil/spread, fire-rate,
        // wallshot, freeze, anti-flash/molotov, always-head and direct
        // gameplay writes do not have validated ARM64 field/method paths in
        // the supplied source. Do not execute legacy writes against 1.0.0.
        //
        // The validated building blocks are exposed by so2_v100_offsets.h;
        // shot/input hooks require a runtime trace of owv serialization.
        (void)esp_invisible;
        (void)esp_addscore;
        (void)esp_inf_ammo;
        (void)esp_no_spread;
        (void)esp_air_jump;
        (void)esp_fast_knife;
        (void)esp_wallshot;
        (void)esp_fire_rate;
        (void)esp_rcs_enabled;
        (void)player_always_head;
        (void)player_freeze_local;
        (void)player_freeze_enemies;

        // The grenade parameter path is likewise not validated for 1.0.0.
        // Keep the menu state, but do not write the old dictionary layout.
        (void)player_anti_flash;
        (void)player_anti_molotov;

            SO2_Matrix viewMatrix = {0};
            if (localPlayer > 0x1000000) {
                mach_vm_address_t v1 = Read<mach_vm_address_t>(localPlayer + 0xE8, so2_task);
                if (v1 > 0x1000000) {
                    mach_vm_address_t v2 = Read<mach_vm_address_t>(v1 + 0x20, so2_task);
                    if (v2 > 0x1000000) {
                        mach_vm_address_t v3 = Read<mach_vm_address_t>(v2 + 0x10, so2_task);
                        if (v3 > 0x1000000) {
                            viewMatrix = Read<SO2_Matrix>(v3 + 0xF0, so2_task);
                        }
                    }
                }
            }

            // Aimbot/triggerbot are not enabled from the old write path.
            // 1.0.0 provides camera/bone/raycast ICalls, but the supplied
            // offsets explicitly do not validate the input/shot submit path.
            // Keeping the old angle writes here would be mixing ARM32 offsets
            // into an ARM64 build.

            BOOL drawBoxes = esp_box_enabled || esp_box_3d || esp_box_fill || esp_box_corner;
            BOOL drawLines = esp_line_enabled;

            if (!drawBoxes && !drawLines && !esp_name_enabled && !esp_health_enabled && !esp_health_bar_enabled && !esp_weapon_enabled && !esp_weapon_icon_enabled && !esp_platform_enabled && !esp_skeleton_enabled) {
                [self clearAllBoxes];
                self.watermarkLabel.text = @" ";
                [self.watermarkLabel sizeToFit];
                return;
            }

            int validPlayers = 0;
            CGFloat w = self.bounds.size.width;
            CGFloat h = self.bounds.size.height;


            for (UILabel *lbl in self.nameLabelPool) lbl.hidden = YES;
            NSUInteger nameLabelIdx = 0;
            for (UILabel *lbl in self.healthLabelPool) lbl.hidden = YES;
            NSUInteger hpLabelIdx = 0;
            for (UILabel *lbl in self.weaponLabelPool) lbl.hidden = YES;
            NSUInteger weaponLabelIdx = 0;
            for (UIImageView *img in self.weaponIconPool) img.hidden = YES;
            NSUInteger weaponIconIdx = 0;
            for (UILabel *lbl in self.platformLabelPool) lbl.hidden = YES;
            NSUInteger platformLabelIdx = 0;
            for (UIImageView *img in self.avatarPool) img.hidden = YES;
            NSUInteger avatarIdx = 0;

            UIBezierPath *boxPath         = [UIBezierPath bezierPath];
            UIBezierPath *boxFillPath     = [UIBezierPath bezierPath];
            UIBezierPath *boxOutlinePath  = [UIBezierPath bezierPath];
            UIBezierPath *linesPath       = [UIBezierPath bezierPath];
            UIBezierPath *lineOutlinePath = [UIBezierPath bezierPath];
            UIBezierPath *healthBarPath   = [UIBezierPath bezierPath];
            UIBezierPath *healthBarOutlinePath = [UIBezierPath bezierPath];
            UIBezierPath *skeletonPath        = [UIBezierPath bezierPath];
            UIBezierPath *skeletonOccludedPath = [UIBezierPath bezierPath];

            int localTeam = -1;
            for (const auto &lp : v100Players) {
                if ((mach_vm_address_t)lp.object == localPlayer) {
                    localTeam = (int)lp.team;
                    break;
                }
            }

            int capacity = (int)v100Players.size();
            for (int i = 0; i < capacity; ++i) {
                const auto &snapshot = v100Players[(size_t)i];
                mach_vm_address_t player = (mach_vm_address_t)snapshot.object;
                if (player < 0x1000000 || player == localPlayer) continue;
                if (!snapshot.alive) continue;

                if (esp_team_check && localTeam >= 0 &&
                    snapshot.team != 0 && (int)snapshot.team == localTeam) continue;

                Vector3 pos = snapshot.position;
                if (!std::isfinite(pos.x) || !std::isfinite(pos.y) || !std::isfinite(pos.z)) continue;
                if (pos.x == 0 && pos.y == 0 && pos.z == 0) continue;

                Vector3 screenFoot = WorldToScreen(pos, viewMatrix, w, h);
                if (screenFoot.z <= 0.01f) continue;

                Vector3 headPos = pos;
                headPos.y += 1.67f;
                Vector3 screenHead = WorldToScreen(headPos, viewMatrix, w, h);

                if (screenHead.z > 0.01f && screenFoot.y > screenHead.y) {
                    validPlayers++;
                    float bh = screenFoot.y - screenHead.y;
                    float bw = bh / 2.0f;

                    

                    if (drawBoxes) {
                        CGRect rect = CGRectMake(screenHead.x - bw / 2.0f, screenHead.y, bw, bh);
                        
                        if (esp_box_fill) {
                            [boxFillPath appendPath:[UIBezierPath bezierPathWithRect:rect]];
                        }
                        
                        if (esp_box_3d) {
                            float bw3d = 0.35f;
                            Vector3 p[8];
                            p[0] = {pos.x - bw3d, pos.y, pos.z - bw3d};
                            p[1] = {pos.x + bw3d, pos.y, pos.z - bw3d};
                            p[2] = {pos.x + bw3d, pos.y, pos.z + bw3d};
                            p[3] = {pos.x - bw3d, pos.y, pos.z + bw3d};

                            p[4] = {headPos.x - bw3d, headPos.y, headPos.z - bw3d};
                            p[5] = {headPos.x + bw3d, headPos.y, headPos.z - bw3d};
                            p[6] = {headPos.x + bw3d, headPos.y, headPos.z + bw3d};
                            p[7] = {headPos.x - bw3d, headPos.y, headPos.z + bw3d};

                            Vector3 sp[8];
                            bool allValid = true;
                            for (int i=0; i<8; i++) {
                                sp[i] = WorldToScreen(p[i], viewMatrix, w, h);
                                if (sp[i].z <= 0) allValid = false;
                            }

                            if (allValid) {
                                auto drawCube = [&](UIBezierPath *pth) {
                                    [pth moveToPoint:CGPointMake(sp[0].x, sp[0].y)]; [pth addLineToPoint:CGPointMake(sp[1].x, sp[1].y)];
                                    [pth addLineToPoint:CGPointMake(sp[2].x, sp[2].y)]; [pth addLineToPoint:CGPointMake(sp[3].x, sp[3].y)];
                                    [pth addLineToPoint:CGPointMake(sp[0].x, sp[0].y)];
                                    [pth moveToPoint:CGPointMake(sp[4].x, sp[4].y)]; [pth addLineToPoint:CGPointMake(sp[5].x, sp[5].y)];
                                    [pth addLineToPoint:CGPointMake(sp[6].x, sp[6].y)]; [pth addLineToPoint:CGPointMake(sp[7].x, sp[7].y)];
                                    [pth addLineToPoint:CGPointMake(sp[4].x, sp[4].y)];
                                    [pth moveToPoint:CGPointMake(sp[0].x, sp[0].y)]; [pth addLineToPoint:CGPointMake(sp[4].x, sp[4].y)];
                                    [pth moveToPoint:CGPointMake(sp[1].x, sp[1].y)]; [pth addLineToPoint:CGPointMake(sp[5].x, sp[5].y)];
                                    [pth moveToPoint:CGPointMake(sp[2].x, sp[2].y)]; [pth addLineToPoint:CGPointMake(sp[6].x, sp[6].y)];
                                    [pth moveToPoint:CGPointMake(sp[3].x, sp[3].y)]; [pth addLineToPoint:CGPointMake(sp[7].x, sp[7].y)];
                                };
                                drawCube(boxPath);
                                if (esp_box_outline) drawCube(boxOutlinePath);
                            } else {

                                [boxPath appendPath:[UIBezierPath bezierPathWithRect:rect]];
                                if (esp_box_outline) [boxOutlinePath appendPath:[UIBezierPath bezierPathWithRect:rect]];
                            }
                        } else if (esp_box_corner) {
                            float cw = bw / 4.0f;
                            float ch = bh / 4.0f;
                            
                            [boxPath moveToPoint:CGPointMake(rect.origin.x, rect.origin.y + ch)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x, rect.origin.y)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x + cw, rect.origin.y)];
                            [boxPath moveToPoint:CGPointMake(rect.origin.x + bw - cw, rect.origin.y)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x + bw, rect.origin.y)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x + bw, rect.origin.y + ch)];
                            [boxPath moveToPoint:CGPointMake(rect.origin.x + bw, rect.origin.y + bh - ch)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x + bw, rect.origin.y + bh)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x + bw - cw, rect.origin.y + bh)];
                            [boxPath moveToPoint:CGPointMake(rect.origin.x + cw, rect.origin.y + bh)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x, rect.origin.y + bh)];
                            [boxPath addLineToPoint:CGPointMake(rect.origin.x, rect.origin.y + bh - ch)];
                            
                            if (esp_box_outline) {
                                [boxOutlinePath appendPath:boxPath];
                            }
                        } else {
                            [boxPath appendPath:[UIBezierPath bezierPathWithRect:rect]];
                            if (esp_box_outline) [boxOutlinePath appendPath:[UIBezierPath bezierPathWithRect:rect]];
                        }
                    }
                    
                    if (drawLines) {
                        [linesPath moveToPoint:CGPointMake(w / 2.0f, 0)];
                        [linesPath addLineToPoint:CGPointMake(screenHead.x, screenHead.y)];
                        if (esp_line_outline) {
                            [lineOutlinePath moveToPoint:CGPointMake(w / 2.0f, 0)];
                            [lineOutlinePath addLineToPoint:CGPointMake(screenHead.x, screenHead.y)];
                        }
                    }

                    if (esp_name_enabled) {
                        UILabel *nameLbl = nil;
                        if (nameLabelIdx < self.nameLabelPool.count) {
                            nameLbl = self.nameLabelPool[nameLabelIdx];
                        } else {
                            nameLbl = [[UILabel alloc] init];
                            nameLbl.userInteractionEnabled = NO;
                            [self addSubview:nameLbl];
                            [self.nameLabelPool addObject:nameLbl];
                        }
                        nameLabelIdx++;
                        
                        UIImageView *avatarView = nil;
                        if (esp_avatar_enabled) {
                            if (avatarIdx < self.avatarPool.count) {
                                avatarView = self.avatarPool[avatarIdx];
                            } else {
                                avatarView = [[UIImageView alloc] init];
                                avatarView.userInteractionEnabled = NO;
                                avatarView.layer.cornerRadius = 2.0;
                                avatarView.clipsToBounds = YES;
                                [self addSubview:avatarView];
                                [self.avatarPool addObject:avatarView];
                            }
                            avatarIdx++;
                        }

                        NSString *nameStr = @"Player";

                        if (esp_name_outline) {
                            NSDictionary *attrs = @{
                                NSFontAttributeName: [UIFont systemFontOfSize:10 weight:UIFontWeightBold],
                                NSForegroundColorAttributeName: [UIColor whiteColor],
                                NSStrokeColorAttributeName: [UIColor blackColor],
                                NSStrokeWidthAttributeName: @(-2.0),
                            };
                            nameLbl.attributedText = [[NSAttributedString alloc] initWithString:nameStr attributes:attrs];
                        } else {
                            nameLbl.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
                            nameLbl.text = nameStr;
                            nameLbl.textColor = [UIColor whiteColor];
                        }

                        [nameLbl sizeToFit];
                        
                        if (esp_avatar_enabled) {
                            NSData *pfpData = nil; // avatar path not validated in 1.0.0
                            if (pfpData) {
                                UIImage *pfpImg = [UIImage imageWithData:pfpData];
                                if (pfpImg) {
                                    avatarView.image = pfpImg;
                                    float avatarSize = 13.0;
                                    float totalWidth = nameLbl.frame.size.width + avatarSize + 4;
                                    
                                    avatarView.frame = CGRectMake(screenHead.x - totalWidth/2.0f, screenHead.y - 10 - avatarSize/2.0f, avatarSize, avatarSize);
                                    nameLbl.center = CGPointMake(screenHead.x + (avatarSize+4)/2.0f, screenHead.y - 10);
                                    avatarView.hidden = NO;
                                } else {
                                    avatarView.hidden = YES;
                                    nameLbl.center = CGPointMake(screenHead.x, screenHead.y - 10);
                                }
                            } else {
                                avatarView.hidden = YES;
                                nameLbl.center = CGPointMake(screenHead.x, screenHead.y - 10);
                            }
                        } else {
                            nameLbl.center = CGPointMake(screenHead.x, screenHead.y - 10);
                        }
                        
                        nameLbl.hidden = NO;
                    }

                    int hpVal = (int)snapshot.hp;
                    if (hpVal > 100) hpVal = 100;
                    if (hpVal < 0) hpVal = 0;
                    float healthPercent = (float)hpVal / 100.0f;
                    float barTopY = screenFoot.y - (bh * healthPercent);
                    float barX = screenHead.x - bw/2.0f - 5;

                    if (esp_health_enabled) {
                        UILabel *hpLbl = nil;
                        if (hpLabelIdx < self.healthLabelPool.count) {
                            hpLbl = self.healthLabelPool[hpLabelIdx];
                        } else {
                            hpLbl = [[UILabel alloc] init];
                            hpLbl.userInteractionEnabled = NO;
                            [self addSubview:hpLbl];
                            [self.healthLabelPool addObject:hpLbl];
                        }
                        hpLabelIdx++;

                        hpLbl.text = [NSString stringWithFormat:@"%d", hpVal];
                        hpLbl.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
                        hpLbl.textColor = [UIColor whiteColor];
                        [hpLbl sizeToFit];
                        
                        float textX = screenHead.x - bw/2.0f - hpLbl.frame.size.width/2.0f - 2;
                        if (esp_health_bar_enabled) {
                            textX -= 6; 
                            hpLbl.center = CGPointMake(textX, barTopY);
                        } else {
                            hpLbl.center = CGPointMake(textX, screenHead.y + hpLbl.frame.size.height/2.0f);
                        }
                        hpLbl.hidden = NO;
                    }

                    if (esp_health_bar_enabled) {
                        float barTopYCalc = screenFoot.y - bh; 
                        
                        [healthBarOutlinePath moveToPoint:CGPointMake(barX, screenFoot.y)];
                        [healthBarOutlinePath addLineToPoint:CGPointMake(barX, barTopYCalc)];
                        
                        [healthBarPath moveToPoint:CGPointMake(barX, screenFoot.y)];
                        [healthBarPath addLineToPoint:CGPointMake(barX, barTopY)];
                    }

                    if (esp_weapon_enabled || esp_weapon_icon_enabled) {
                        UILabel *weaponLbl = nil;
                        if (weaponLabelIdx < self.weaponLabelPool.count) {
                            weaponLbl = self.weaponLabelPool[weaponLabelIdx];
                        } else {
                            weaponLbl = [[UILabel alloc] init];
                            weaponLbl.userInteractionEnabled = NO;
                            [self addSubview:weaponLbl];
                            [self.weaponLabelPool addObject:weaponLbl];
                        }
                        weaponLabelIdx++;

                        UIImageView *iconView = nil;
                        if (weaponIconIdx < self.weaponIconPool.count) {
                            iconView = self.weaponIconPool[weaponIconIdx];
                        } else {
                            iconView = [[UIImageView alloc] init];
                            iconView.userInteractionEnabled = NO;
                            iconView.contentMode = UIViewContentModeScaleAspectFit;
                            [self addSubview:iconView];
                            [self.weaponIconPool addObject:iconView];
                        }
                        weaponIconIdx++;

                        NSString *weaponStr = @"";
                        if (snapshot.weaponId != 0) {
                            weaponStr = [NSString stringWithFormat:@"ID %u  |  Ammo %u",
                                         (unsigned)snapshot.weaponId,
                                         (unsigned)snapshot.ammo];
                        }

                        if (weaponStr.length > 0) {
                            NSString *lowerStr = weaponStr.lowercaseString;
                            UIImage *iconImg = nil;
                            
                            // MAPPING
                            if ([lowerStr containsString:@"akr12"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__akr12 length:sizeof(__akr12)]]; weaponStr = @"AKR12"; }
                            else if ([lowerStr containsString:@"akr"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__akr length:sizeof(__akr)]]; weaponStr = @"AK-47"; }
                            else if ([lowerStr containsString:@"famas"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__famas length:sizeof(__famas)]]; weaponStr = @"Famas"; }
                            else if ([lowerStr containsString:@"fnfal"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__fnfal length:sizeof(__fnfal)]]; weaponStr = @"FNFAL"; }
                            else if ([lowerStr containsString:@"m16"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m16 length:sizeof(__m16)]]; weaponStr = @"M16"; }
                            else if ([lowerStr containsString:@"m4a1"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m4 length:sizeof(__m4)]]; weaponStr = @"M4A1"; }
                            else if ([lowerStr containsString:@"m4"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m4 length:sizeof(__m4)]]; weaponStr = @"M4"; }
                            else if ([lowerStr containsString:@"val"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__val length:sizeof(__val)]]; weaponStr = @"AS VAL"; }
                            // Pistols
                            else if ([lowerStr containsString:@"g22"] || [lowerStr containsString:@"glock"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__g22 length:sizeof(__g22)]]; weaponStr = @"G22"; }
                            else if ([lowerStr containsString:@"deagle"] || [lowerStr containsString:@"desert"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__desert_eagle length:sizeof(__desert_eagle)]]; weaponStr = @"Deagle"; }
                            else if ([lowerStr containsString:@"usp"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__usp length:sizeof(__usp)]]; weaponStr = @"USP"; }
                            else if ([lowerStr containsString:@"p350"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__p350 length:sizeof(__p350)]]; weaponStr = @"P350"; }
                            else if ([lowerStr containsString:@"tec9"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__tec9 length:sizeof(__tec9)]]; weaponStr = @"TEC-9"; }
                            else if ([lowerStr containsString:@"five"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__five_seven length:sizeof(__five_seven)]]; weaponStr = @"FS"; }
                            else if ([lowerStr containsString:@"berettas"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__berettas length:sizeof(__berettas)]]; weaponStr = @"Dual Berettas"; }
                            // SMGs
                            else if ([lowerStr containsString:@"mac10"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__mac10 length:sizeof(__mac10)]]; weaponStr = @"MAC-10"; }
                            else if ([lowerStr containsString:@"mp5"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__mp5 length:sizeof(__mp5)]]; weaponStr = @"MP5"; }
                            else if ([lowerStr containsString:@"mp7"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__mp7 length:sizeof(__mp7)]]; weaponStr = @"MP7"; }
                            else if ([lowerStr containsString:@"p90"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__p90 length:sizeof(__p90)]]; weaponStr = @"P90"; }
                            else if ([lowerStr containsString:@"ump45"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__ump45 length:sizeof(__ump45)]]; weaponStr = @"UMP45"; }
                            else if ([lowerStr containsString:@"uzi"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__uzi length:sizeof(__uzi)]]; weaponStr = @"UZI"; }
                            // Snipers
                            else if ([lowerStr containsString:@"awm"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__awm length:sizeof(__awm)]]; weaponStr = @"AWM"; }
                            else if ([lowerStr containsString:@"m110"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m110 length:sizeof(__m110)]]; weaponStr = @"M110"; }
                            else if ([lowerStr containsString:@"m40"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m40 length:sizeof(__m40)]]; weaponStr = @"M40"; }
                            else if ([lowerStr containsString:@"mallard"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__mallard length:sizeof(__mallard)]]; weaponStr = @"Mallard"; }
                            // Heavy
                            else if ([lowerStr containsString:@"fabm"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__fabm length:sizeof(__fabm)]]; weaponStr = @"Fabarm"; }
                            else if ([lowerStr containsString:@"m60"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m60 length:sizeof(__m60)]]; weaponStr = @"M60"; }
                            else if ([lowerStr containsString:@"sm1014"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__sm1014 length:sizeof(__sm1014)]]; weaponStr = @"SM1014"; }
                            else if ([lowerStr containsString:@"spas"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__spas length:sizeof(__spas)]]; weaponStr = @"SPAS-12"; }
                            // Grenades
                            else if ([lowerStr containsString:@"flash"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__flash length:sizeof(__flash)]]; weaponStr = @"Flash"; }
                            else if ([lowerStr containsString:@"he"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__he length:sizeof(__he)]]; weaponStr = @"HE"; }
                            else if ([lowerStr containsString:@"molotov"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__molotov length:sizeof(__molotov)]]; weaponStr = @"Molotov"; }
                            else if ([lowerStr containsString:@"smoke"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__smoke length:sizeof(__smoke)]]; weaponStr = @"Smoke"; }
                            else if ([lowerStr containsString:@"thermite"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__thermite length:sizeof(__thermite)]]; weaponStr = @"Thermite"; }
                            // Knives   (test)
                            else if ([lowerStr containsString:@"butterfly"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__butterfly length:sizeof(__butterfly)]]; weaponStr = @"Butterfly"; }
                            else if ([lowerStr containsString:@"karambit"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__karambit length:sizeof(__karambit)]]; weaponStr = @"Karambit"; }
                            else if ([lowerStr containsString:@"m9"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__m9bayonet length:sizeof(__m9bayonet)]]; weaponStr = @"M9 Bayonet"; }
                            else if ([lowerStr containsString:@"tanto"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__tanto length:sizeof(__tanto)]]; weaponStr = @"Tanto"; }
                            else if ([lowerStr containsString:@"flip"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__flipknife length:sizeof(__flipknife)]]; weaponStr = @"Flip Knife"; }
                            else if ([lowerStr containsString:@"jkommando"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__jkommando length:sizeof(__jkommando)]]; weaponStr = @"Jkommando"; }
                            else if ([lowerStr containsString:@"scorpion"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__scorpion length:sizeof(__scorpion)]]; weaponStr = @"Scorpion"; }
                            else if ([lowerStr containsString:@"stiletto"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__stiletto length:sizeof(__stiletto)]]; weaponStr = @"Stiletto"; }
                            else if ([lowerStr containsString:@"kukri"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__kukri length:sizeof(__kukri)]]; weaponStr = @"Kukri"; }
                            else if ([lowerStr containsString:@"kunai"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__kunai length:sizeof(__kunai)]]; weaponStr = @"Kunai"; }
                            else if ([lowerStr containsString:@"fang"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__fang length:sizeof(__fang)]]; weaponStr = @"Fang"; }
                            else if ([lowerStr containsString:@"dual"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__dual_daggers length:sizeof(__dual_daggers)]]; weaponStr = @"Dual Daggers"; }
                            else if ([lowerStr containsString:@"kabar"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__kabar length:sizeof(__kabar)]]; weaponStr = @"Kabar"; }
                            else if ([lowerStr containsString:@"mantis"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__mantis length:sizeof(__mantis)]]; weaponStr = @"Mantis"; }
                            else if ([lowerStr containsString:@"sting"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__sting length:sizeof(__sting)]]; weaponStr = @"Sting"; }
                            else if ([lowerStr containsString:@"knife"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__karambit length:sizeof(__karambit)]]; weaponStr = @"Knife"; } // Default knife icon
                            // Other
                            else if ([lowerStr containsString:@"bomb"]) { iconImg = [UIImage imageWithData:[NSData dataWithBytes:__bomb length:sizeof(__bomb)]]; weaponStr = @"BOMB"; }

                            if (esp_weapon_enabled) {
                                if (esp_name_outline) {
                                    NSDictionary *attrs = @{
                                        NSFontAttributeName: [UIFont systemFontOfSize:10 weight:UIFontWeightBold],
                                        NSForegroundColorAttributeName: [UIColor whiteColor],
                                        NSStrokeColorAttributeName: [UIColor blackColor],
                                        NSStrokeWidthAttributeName: @(-2.0),
                                    };
                                    weaponLbl.attributedText = [[NSAttributedString alloc] initWithString:weaponStr attributes:attrs];
                                } else {
                                    weaponLbl.attributedText = nil;
                                    weaponLbl.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
                                    weaponLbl.textColor = [UIColor whiteColor];
                                    weaponLbl.text = weaponStr;
                                }
                                [weaponLbl sizeToFit];
                                weaponLbl.center = CGPointMake(screenHead.x, screenFoot.y + weaponLbl.frame.size.height/2.0f + 2);
                                weaponLbl.hidden = NO;
                            } else {
                                weaponLbl.hidden = YES;
                            }

                            if (esp_weapon_icon_enabled && iconImg) {
                                iconView.image = iconImg;
                                iconView.frame = CGRectMake(0, 0, 30, 15);
                                CGFloat yIcon = screenFoot.y + 10;
                                if (esp_weapon_enabled) {
                                    yIcon = weaponLbl.center.y + weaponLbl.frame.size.height/2.0f + 10;
                                }
                                iconView.center = CGPointMake(screenHead.x, yIcon);
                                iconView.hidden = NO;
                            } else {
                                iconView.hidden = YES;
                            }
                        } else {
                            weaponLbl.hidden = YES;
                            iconView.hidden = YES;
                        }
                    }

                    if (esp_platform_enabled) {
                        UILabel *plLbl = nil;
                        if (platformLabelIdx < self.platformLabelPool.count) {
                            plLbl = self.platformLabelPool[platformLabelIdx];
                        } else {
                            plLbl = [[UILabel alloc] init];
                            plLbl.userInteractionEnabled = NO;
                            plLbl.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
                            plLbl.textColor = [UIColor whiteColor];
                            [self addSubview:plLbl];
                            [self.platformLabelPool addObject:plLbl];
                        }
                        platformLabelIdx++;

                        int platformVal = 0; // platform field is not validated in 1.0.0

                        NSString *plStr = @"Unknown";
                        if (platformVal == 1) plStr = @"Android";
                        else if (platformVal == 2) plStr = @"iOS";
                        
                        plLbl.text = plStr;
                        [plLbl sizeToFit];
                        
                        plLbl.center = CGPointMake(screenHead.x + bw/2.0f + plLbl.frame.size.width/2.0f + 4, screenHead.y + plLbl.frame.size.height/2.0f);
                        plLbl.hidden = NO;
                    }
                }
            }
            self.playerCountLabel.text = [NSString stringWithFormat:@"@x1work | Players: %d", (int)validPlayers];
            self.playerCountLabel.hidden = NO;
            [self.playerCountLabel sizeToFit];

            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            self.espBoxFillLayer.path     = (drawBoxes && esp_box_fill) ? boxFillPath.CGPath : nil;
            self.espBoxLayer.path         = drawBoxes ? boxPath.CGPath : nil;
            self.espBoxOutlineLayer.path  = (drawBoxes && esp_box_outline) ? boxOutlinePath.CGPath : nil;
            self.espLineLayer.path        = drawLines ? linesPath.CGPath : nil;
            self.espLineOutlineLayer.path = (drawLines && esp_line_outline) ? lineOutlinePath.CGPath : nil;
            self.espHealthBarLayer.path = esp_health_bar_enabled ? healthBarPath.CGPath : nil;
            self.espHealthBarOutlineLayer.path = (esp_health_bar_enabled && esp_health_bar_outline) ? healthBarOutlinePath.CGPath : nil;
            self.espSkeletonLayer.path = esp_skeleton_enabled ? skeletonPath.CGPath : nil;
            self.espSkeletonOccludedLayer.path = (esp_skeleton_enabled && esp_skeleton_occluded) ? skeletonOccludedPath.CGPath : nil;
            [CATransaction commit];
            [CATransaction flush];

            self.watermarkLabel.text = @(OBF(" "));
            [self.watermarkLabel sizeToFit];
            return;
        }

CLEAR_BOXES:
    [self clearAllBoxes];
    self.watermarkLabel.text = @" ";
    [self.watermarkLabel sizeToFit];

    self.playerCountLabel.textColor = [[UIColor greenColor] colorWithAlphaComponent:0.5];
    self.playerCountLabel.text      = @"PLAYERS: 0";
    self.playerCountLabel.hidden    = !self.isESPCountEnabled;
    self.noPlayersLabel.hidden      = YES;
}

- (void)runAimbot:(mach_vm_address_t)localPlayer
          players:(mach_vm_address_t)playersList
            count:(int)count
        localTeam:(int)localTeam
             task:(task_t)so2_task
            width:(CGFloat)w
           height:(CGFloat)h
       viewMatrix:(SO2_Matrix)viewMatrix {
    // 1.0.0 input/shot submit path is not validated by the supplied offsets.
    // Do not execute the previous ARM32 angle writes.
    (void)localPlayer;
    return;
}

- (void)launchGame {
    [[LSApplicationWorkspace defaultWorkspace]
        openApplicationWithBundleID:@(OBF("com.axlebolt.standoff2"))];
}

- (void)startBackgroundKeeper {
    [[AVAudioSession sharedInstance]
        setCategory:AVAudioSessionCategoryPlayback
        withOptions:AVAudioSessionCategoryOptionMixWithOthers
        error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];

    NSString *silentPath = [[NSBundle mainBundle] pathForResource:@"silent" ofType:@"wav"];
    NSURL *url = silentPath.length ? [NSURL fileURLWithPath:silentPath] : nil;
    if (!url) return;
    self.backgroundPlayer                 = [[AVPlayer alloc] initWithURL:url];
    self.backgroundPlayer.volume          = 0.0f;
    self.backgroundPlayer.actionAtItemEnd = AVPlayerActionAtItemEndNone;

    [[NSNotificationCenter defaultCenter]
        addObserver:self
           selector:@selector(playerItemDidReachEnd:)
               name:AVPlayerItemDidPlayToEndTimeNotification
             object:self.backgroundPlayer.currentItem];

    [self.backgroundPlayer play];
}

- (void)playerItemDidReachEnd:(NSNotification *)notification {
    [(AVPlayerItem *)notification.object seekToTime:kCMTimeZero completionHandler:nil];
}

@end
