#import "cfg.h"
#import "tt.h"
#include "obfusheader.h"

extern volatile bool esp_screenshot_safe;

NSString *cfg_get_dir() {
    NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *confDir = [docs stringByAppendingPathComponent:@(OBF("@x1work"))];
    [[NSFileManager defaultManager] createDirectoryAtPath:confDir withIntermediateDirectories:YES attributes:nil error:nil];
    return confDir;
}

NSArray<NSString*> *cfg_get_list() {
    NSString *confDir = cfg_get_dir();
    NSArray *files = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:confDir error:nil];
    NSMutableArray *configs = [NSMutableArray array];
    for (NSString *f in files) {
        if ([f hasSuffix:@(OBF(".plist"))]) {
            [configs addObject:[f stringByDeletingPathExtension]];
        }
    }
    return configs;
}

void cfg_create(NSString *name) {
    if (name.length == 0) return;
    NSString *path = [cfg_get_dir() stringByAppendingPathComponent:[NSString stringWithFormat:@(OBF("%@.plist")), name]];
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    dict[@(OBF("esp_box_enabled"))] = @(esp_box_enabled);
    dict[@(OBF("esp_box_outline"))] = @(esp_box_outline);
    dict[@(OBF("esp_box_fill"))] = @(esp_box_fill);
    dict[@(OBF("esp_box_corner"))] = @(esp_box_corner);
    dict[@(OBF("esp_box_3d"))] = @(esp_box_3d);
    dict[@(OBF("esp_line_enabled"))] = @(esp_line_enabled);
    dict[@(OBF("esp_line_outline"))] = @(esp_line_outline);
    
    dict[@(OBF("esp_name_enabled"))] = @(esp_name_enabled);
    dict[@(OBF("esp_name_outline"))] = @(esp_name_outline);
    dict[@(OBF("esp_health_enabled"))] = @(esp_health_enabled);
    dict[@(OBF("esp_health_bar_enabled"))] = @(esp_health_bar_enabled);
    dict[@(OBF("esp_health_bar_outline"))] = @(esp_health_bar_outline);
    dict[@(OBF("esp_weapon_enabled"))] = @(esp_weapon_enabled);
    dict[@(OBF("esp_weapon_icon_enabled"))] = @(esp_weapon_icon_enabled);
    dict[@(OBF("esp_platform_enabled"))] = @(esp_platform_enabled);
    dict[@(OBF("esp_avatar_enabled"))] = @(esp_avatar_enabled);

    dict[@(OBF("esp_skeleton_enabled"))] = @(esp_skeleton_enabled);
    dict[@(OBF("esp_skeleton_occluded"))] = @(esp_skeleton_occluded);

    dict[@(OBF("viewmodel_enabled"))] = @(viewmodel_enabled);
    dict[@(OBF("viewmodel_x"))] = @(viewmodel_x);
    dict[@(OBF("viewmodel_y"))] = @(viewmodel_y);
    dict[@(OBF("viewmodel_z"))] = @(viewmodel_z);

    dict[@(OBF("esp_auto_load"))] = @(esp_auto_load);
    dict[@(OBF("esp_screenshot_safe"))] = @(esp_screenshot_safe);
    dict[@(OBF("player_always_head"))] = @(player_always_head);
    dict[@(OBF("player_freeze_local"))] = @(player_freeze_local);
    dict[@(OBF("player_freeze_enemies"))] = @(player_freeze_enemies);
    dict[@(OBF("player_anti_flash"))] = @(player_anti_flash);
    dict[@(OBF("player_anti_molotov"))] = @(player_anti_molotov);

    [dict writeToFile:path atomically:YES];
}

void cfg_load(NSString *name) {
    if (name.length == 0) return;
    NSString *path = [cfg_get_dir() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", name]];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
    if (!dict) return;
    
    if (dict[@(OBF("esp_box_enabled"))]) esp_box_enabled = [dict[@(OBF("esp_box_enabled"))] boolValue];
    if (dict[@(OBF("esp_box_outline"))]) esp_box_outline = [dict[@(OBF("esp_box_outline"))] boolValue];
    if (dict[@(OBF("esp_box_fill"))]) esp_box_fill = [dict[@(OBF("esp_box_fill"))] boolValue];
    if (dict[@(OBF("esp_box_corner"))]) esp_box_corner = [dict[@(OBF("esp_box_corner"))] boolValue];
    if (dict[@(OBF("esp_box_3d"))]) esp_box_3d = [dict[@(OBF("esp_box_3d"))] boolValue];
    if (dict[@(OBF("esp_line_enabled"))]) esp_line_enabled = [dict[@(OBF("esp_line_enabled"))] boolValue];
    if (dict[@(OBF("esp_line_outline"))]) esp_line_outline = [dict[@(OBF("esp_line_outline"))] boolValue];
    if (dict[@(OBF("esp_team_check"))]) esp_team_check = [dict[@(OBF("esp_team_check"))] boolValue];
    
    if (dict[@(OBF("esp_name_enabled"))]) esp_name_enabled = [dict[@(OBF("esp_name_enabled"))] boolValue];
    if (dict[@(OBF("esp_name_outline"))]) esp_name_outline = [dict[@(OBF("esp_name_outline"))] boolValue];
    if (dict[@(OBF("esp_health_enabled"))]) esp_health_enabled = [dict[@(OBF("esp_health_enabled"))] boolValue];
    if (dict[@(OBF("esp_health_bar_enabled"))]) esp_health_bar_enabled = [dict[@(OBF("esp_health_bar_enabled"))] boolValue];
    if (dict[@(OBF("esp_health_bar_outline"))]) esp_health_bar_outline = [dict[@(OBF("esp_health_bar_outline"))] boolValue];
    if (dict[@(OBF("esp_weapon_enabled"))]) esp_weapon_enabled = [dict[@(OBF("esp_weapon_enabled"))] boolValue];
    if (dict[@(OBF("esp_weapon_icon_enabled"))]) esp_weapon_icon_enabled = [dict[@(OBF("esp_weapon_icon_enabled"))] boolValue];
    if (dict[@(OBF("esp_platform_enabled"))]) esp_platform_enabled = [dict[@(OBF("esp_platform_enabled"))] boolValue];
    if (dict[@(OBF("esp_avatar_enabled"))]) esp_avatar_enabled = [dict[@(OBF("esp_avatar_enabled"))] boolValue];

    if (dict[@(OBF("esp_skeleton_enabled"))]) esp_skeleton_enabled = [dict[@(OBF("esp_skeleton_enabled"))] boolValue];
    if (dict[@(OBF("esp_skeleton_occluded"))]) esp_skeleton_occluded = [dict[@(OBF("esp_skeleton_occluded"))] boolValue];

    if (dict[@(OBF("viewmodel_enabled"))]) viewmodel_enabled = [dict[@(OBF("viewmodel_enabled"))] boolValue];
    if (dict[@(OBF("viewmodel_x"))]) viewmodel_x = [dict[@(OBF("viewmodel_x"))] floatValue];
    if (dict[@(OBF("viewmodel_y"))]) viewmodel_y = [dict[@(OBF("viewmodel_y"))] floatValue];
    if (dict[@(OBF("viewmodel_z"))]) viewmodel_z = [dict[@(OBF("viewmodel_z"))] floatValue];
    
    if (dict[@(OBF("esp_auto_load"))]) esp_auto_load = [dict[@(OBF("esp_auto_load"))] boolValue];
    if (dict[@(OBF("esp_screenshot_safe"))]) esp_screenshot_safe = [dict[@(OBF("esp_screenshot_safe"))] boolValue];
    if (dict[@(OBF("player_always_head"))]) player_always_head = [dict[@(OBF("player_always_head"))] boolValue];
    if (dict[@(OBF("player_freeze_local"))]) player_freeze_local = [dict[@(OBF("player_freeze_local"))] boolValue];
    if (dict[@(OBF("player_freeze_enemies"))]) player_freeze_enemies = [dict[@(OBF("player_freeze_enemies"))] boolValue];
    if (dict[@(OBF("player_anti_flash"))]) player_anti_flash = [dict[@(OBF("player_anti_flash"))] boolValue];
    if (dict[@(OBF("player_anti_molotov"))]) player_anti_molotov = [dict[@(OBF("player_anti_molotov"))] boolValue];
}

void cfg_delete(NSString *name) {
    if (name.length == 0) return;
    NSString *path = [cfg_get_dir() stringByAppendingPathComponent:[NSString stringWithFormat:@(OBF("%@.plist")), name]];
    [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
}
