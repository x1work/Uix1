#pragma once

#include <mach/mach.h>
#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

//LazySingleton<GrenadeEffectEmitter>._instance.parameters
void LTGrenadeEmitter_Tick(uint64_t unityBase, task_t task,
                           int antifleshka, int antimolik);


uint64_t LTGrenadeEmitter_ParametersForId(uint64_t unityBase, task_t task,
                                          int weaponId);

#ifdef __cplusplus
}
#endif
