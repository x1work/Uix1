#pragma once

#include <mach/mach.h>
#include <stdint.h>

namespace AlwaysHead {

struct Config {
  float radius = 0.87556f;   // native CapsuleCollider + 0x60
  float height = 2.03431f;   // native CapsuleCollider + 0x64

  int   maxEntries = 64;
};

int apply(uint64_t pc, uint64_t localPlayer, task_t task,
          const Config &cfg = Config{});

}  // namespace AlwaysHead
