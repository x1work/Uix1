#pragma once

#include <mach/mach.h>
#include <stdint.h>
#include <float.h>
#include <math.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "../helpers/Vector3.h"

namespace Aim360 {

struct Context {
    Vector3 cameraPos{0, 0, 0};
    float currentPitch = 0.0f;
    float currentYaw = 0.0f;
    bool ready = false;
};

// Builds the camera/aim context used when the Aimbot FOV slider is set to 360.
Context Prepare(uint64_t localPlayer, task_t task);

// Returns the angular rotation required to face targetPos, or FLT_MAX when
// no usable 360 context is available.
float TargetScore(const Context &ctx, const Vector3 &targetPos);

} // namespace Aim360
