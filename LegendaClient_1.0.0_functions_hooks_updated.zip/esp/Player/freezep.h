#pragma once

#include <mach/mach.h>
#include <stdint.h>

namespace FreezePlayers {

void ApplyLocal(uint64_t localPlayer, task_t task);

void ApplyEnemy(uint64_t enemyPlayer, task_t task);

inline void ApplyBoth(uint64_t localPlayer, uint64_t enemyPlayer,
                      task_t task) {
  ApplyLocal(localPlayer, task);
  ApplyEnemy(enemyPlayer, task);
}

}  // namespace FreezePlayers
